# Kivi Financial Engine — Approved Policy Update (v0.3.1)

This package is the v0.3 prototype engine with founder-approved salary-delay, uncapped allowance, and optional reserve behavior implemented. It is **not** a production-ready banking backend or complete mobile application.

Run tests: `python -m unittest discover -s tests -t . -q` from this `kivi` directory.

Read `APPROVED_POLICIES.md` for approved rules and unresolved production decisions. `TRACEABILITY.md` is retained from v0.3 as historical reference; its descriptions of the old 7-day salary assumption and surplus cap are superseded.

# Kivi engine (prototype)

Deterministic money logic for Kivi. Pure Python 3.11+, standard library only, no cost to run.

    python3 demo.py                 # simulated user across the 28 Oct–27 Nov cycle
    python3 demo.py stacked 7       # other persona (foodie | saver | stacked) and seed
    python3 -m unittest discover -s tests -t .

## Layout
- `kivi_engine/cycle.py`      salary cycles
- `kivi_engine/ledger.py`     ingestion, dedupe/reconciliation, balances, audit
- `kivi_engine/safe2spend.py` the Safe 2 Spend calculation
- `kivi_engine/insights.py`   evidence-based roast detection
- `kivi_engine/voice.py`      Kivi's tone routing and wording (no math)
- `kivi_engine/aa_adapter.py` AA-style payload and SMS → ledger (**verify field names against the real Setu/Finvu sandbox**)
- `kivi_engine/simulator.py`  synthetic users that emit AA-style transactions
- `kivi_engine/runner.py`     `World`: advance a day, or press "I just spent"
- `kivi_engine/config.py`     every open product decision, with a labeled default

## Rule for the no-code/AI UI tools
Keep every number in this engine. UI tools (Replit, Emergent, Manus) should only call it and display results; do not let generated UI code recompute allowances.

## Limits
Synthetic data validates the experience and the math, not accuracy or trust on real finances.
