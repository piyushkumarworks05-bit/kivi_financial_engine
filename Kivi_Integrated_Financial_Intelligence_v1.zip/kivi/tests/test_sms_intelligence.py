import unittest
from datetime import datetime,timezone
from kivi_engine.sms import assess_sms,parse_sms
from kivi_engine.ledger import Ledger,Account,AcctType,RawEvent,Kind
NOW=datetime(2026,10,23,10,0,tzinfo=timezone.utc)
class SMSIntelligenceTests(unittest.TestCase):
 def a(self,s,**kw):return assess_sms(s,'bank1',NOW,**kw)
 def test_basic_debit(self):
  x=self.a('A/c XX1234 debited by Rs 500.00 on 23/10/2026. UPI Ref 512345678901. Avl Bal Rs 4,500.00')
  self.assertEqual(x.status,'accepted');self.assertEqual(x.raw_event.amount_paise,50000);self.assertEqual(x.balance_paise,450000)
  self.assertEqual(x.raw_event.ref,'512345678901')
 def test_credit(self):self.assertEqual(self.a('Rs. 2,000 credited to A/c XX1234 UTR 512345678901').raw_event.direction,'credit')
 def test_salary_unconfirmed(self):
  x=self.a('Salary of INR 60,000 credited to A/c XX1234 Ref 512345678901')
  self.assertTrue(x.raw_event.salary_candidate);self.assertEqual(x.raw_event.kind,Kind.INCOME)
 def test_refund(self):self.assertEqual(self.a('Refund of Rs 399 credited to A/c XX1234 Ref 512345678901').raw_event.kind,Kind.REFUND)
 def test_failed(self):self.assertEqual(self.a('A/c XX1234 not debited Rs 500 due to rejection').status,'ignored')
 def test_future(self):self.assertEqual(self.a('Rs 500 will be debited tomorrow from A/c XX1234').status,'ignored')
 def test_otp(self):self.assertEqual(self.a('OTP 123456 for debit of Rs 500').status,'ignored')
 def test_promo(self):self.assertEqual(self.a('Congratulations! Rs 500 credited offer ends tonight').status,'ignored')
 def test_card_not_credit(self):
  x=self.a('Your credit card XX1234 spent Rs 450 at CAFE. Ref 512345678901')
  self.assertEqual(x.raw_event.direction,'debit');self.assertEqual(x.raw_event.kind,Kind.CARD_PURCHASE)
 def test_card_payment(self):self.assertEqual(self.a('Credit card bill paid Rs 500 from A/c XX1234 Ref 512345678901').raw_event.kind,Kind.CARD_PAYMENT)
 def test_multiple_amounts(self):self.assertEqual(self.a('A/c XX1234 debited Rs 500 plus fee Rs 10').status,'review')
 def test_balance_not_amount(self):self.assertEqual(self.a('A/c XX1234 debited Rs 50. Avl Bal Rs 500').raw_event.amount_paise,5000)
 def test_no_ref_no_guess(self):self.assertIsNone(self.a('Rs 100 debited A/c XX1234').raw_event.ref)
 def test_account_mismatch(self):self.assertEqual(self.a('A/c XX1234 debited Rs 500',expected_account_tail='5678').status,'review')
 def test_numeric_sender(self):self.assertEqual(self.a('A/c XX1234 debited Rs 500',sender='+919876543210').status,'review')
 def test_idempotent_sms(self):
  l=Ledger();l.add_account(Account('bank1',AcctType.SAVINGS))
  x=self.a('A/c XX1234 debited Rs 500 Ref 512345678901',source_id='sms1').raw_event
  self.assertEqual(l.ingest(x).status,'new');self.assertEqual(l.ingest(x).status,'replay')
 def test_aa_sms_merge(self):
  l=Ledger();l.add_account(Account('bank1',AcctType.SAVINGS))
  sms=self.a('A/c XX1234 debited Rs 500 UPI Ref 512345678901',source_id='s1').raw_event
  aa=RawEvent('aa','a1','bank1','debit',50000,NOW,Kind.SPEND,ref='512345678901')
  self.assertEqual(l.ingest(sms).status,'new');self.assertEqual(l.ingest(aa).status,'merged');self.assertEqual(len(l.events),1)
 def test_identical_distinct_payments(self):
  l=Ledger();l.add_account(Account('bank1',AcctType.SAVINGS))
  a=self.a('A/c XX1234 debited Rs 50',source_id='s1').raw_event
  b=self.a('A/c XX1234 debited Rs 50',source_id='s2').raw_event
  l.ingest(a);l.ingest(b);self.assertEqual(len(l.events),2)
 def test_bad_date_fallback(self):self.assertEqual(self.a('Rs 500 debited on 31/02/2026').raw_event.ts,NOW)
 def test_missing_amount(self):self.assertEqual(self.a('A/c XX1234 debited today').status,'review')
 def test_no_merchant_invention(self):self.assertIsNone(self.a('A/c XX1234 debited Rs 500').raw_event.merchant)
 def test_date_parsing(self):self.assertEqual(self.a('Rs 500 debited on 22/10/2026').raw_event.ts.day,22)
 def test_vpa(self):self.assertEqual(self.a('Rs 500 paid to cafe@okaxis UPI Ref 512345678901').raw_event.merchant,'cafe')
if __name__=='__main__':unittest.main()
