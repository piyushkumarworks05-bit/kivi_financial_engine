import unittest,tempfile
from datetime import datetime,date,timedelta,timezone
from pathlib import Path
from kivi_engine.storage import Store
from kivi_engine.ledger import Account,AcctType,RawEvent,Kind,Ledger
from kivi_engine.intelligence import spending,ghost_candidates,habit_reduction,goal_forecast,roast_facts,target_progress
from kivi_engine.demo_aa import load_synthetic_profile
from kivi_engine.service import dashboard

NOW=datetime(2026,10,23,12,tzinfo=timezone.utc)
class IntelligenceTests(unittest.TestCase):
 def setUp(self):
  self.ledger=Ledger();self.ledger.add_account(Account('a',AcctType.SAVINGS,'Bank'))
 def tx(self,id,amount,merchant,category='food',day=1,kind=Kind.SPEND):
  self.ledger.ingest(RawEvent('aa',str(id),'a','debit',amount,NOW-timedelta(days=day),kind,merchant,category))
 def test_group_and_percent(self):
  self.tx(1,10000,'Toing');self.tx(2,20000,'Swiggy')
  r=spending(self.ledger,date(2026,10,1),date(2026,10,23),NOW,100000)
  self.assertEqual(r['merchant_groups_paise']['Swiggy'],30000)
  self.assertEqual(r['percent_of_income']['food'],30)
 def test_targets_do_not_reserve(self):
  self.tx(1,5000,'Swiggy')
  r=target_progress(self.ledger,[{'id':'x','merchant_or_category':'Swiggy','period_start':'2026-10-01','period_end':'2026-10-31','ceiling_paise':4000}],NOW)
  self.assertTrue(r[0]['exceeded']);self.assertEqual(r[0]['reserved_money_paise'],0)
 def test_sensitive_excluded_from_roast(self):
  self.tx(1,3000,'Hospital','medical')
  self.assertFalse(roast_facts(self.ledger,date(2026,10,1),date(2026,10,23),NOW)['eligible'])
 def test_projection_not_realized(self):
  self.assertEqual(habit_reduction(300000,10)['realized_savings_paise'],0)
 def test_goal_forecast(self):
  self.assertEqual(goal_forecast(100000,10000,30000)['estimated_months'],3)
 def test_demo_isolation(self):
  with tempfile.TemporaryDirectory() as d:
   s=Store(Path(d)/'x.db')
   with self.assertRaises(ValueError):load_synthetic_profile(s,'realuser',NOW)
   load_synthetic_profile(s,'demo:1',NOW)
   self.assertEqual(len(s.load('realuser')[0].events),0)
   self.assertEqual(len(s.load('demo:1')[0].events),3)
   self.assertTrue(dashboard(s,'demo:1',NOW)['roast_receipt']['eligible'])
   s.close()
 def test_ghost_suspected(self):
  self.tx(1,39900,'MusicService',day=31);self.tx(2,39900,'MusicService',day=1)
  self.assertEqual(ghost_candidates(self.ledger,NOW)[0]['status'],'suspected')
if __name__=='__main__':unittest.main()
