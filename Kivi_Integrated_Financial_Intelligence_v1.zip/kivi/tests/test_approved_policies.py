"""Founder-approved financial policies and safety regressions."""
import unittest
from dataclasses import replace
from datetime import date, timedelta
from tests.test_engine import at, make_ledger, spend
from kivi_engine.config import DEFAULT
from kivi_engine.ledger import RawEvent, Kind
from kivi_engine.money import rupees
from kivi_engine.safe2spend import compute
from kivi_engine.voice import kivi_says

class ApprovedPolicyTests(unittest.TestCase):
    def test_late_salary_withholds_allowance_and_requests_revised_date(self):
        L = make_ledger(6000, date(2026,11,29), date(2026,10,28))
        r = compute(L, at(date(2026,11,29),12), next_payday=date(2026,11,28))
        self.assertEqual(r.state, 'awaiting_payday')
        self.assertEqual(r.display_allowance_today, 0)
        self.assertIn('revised', kivi_says(r).lower())

    def test_user_revised_payday_is_estimate_not_confirmed_salary(self):
        L = make_ledger(6000, date(2026,11,29), date(2026,10,28))
        r = compute(L, at(date(2026,11,29),12), next_payday=date(2026,12,3))
        self.assertEqual((r.state,r.days_remaining,r.allowance_today), ('ok',4,rupees(1500)))
        self.assertEqual(r.cycle.end_provenance, 'confirmed_forecast')
        self.assertEqual(len(L.confirmed_salary_dates(at(date(2026,11,29),12))), 1)

    def test_repeated_delay_requires_new_date(self):
        L = make_ledger(6000, date(2026,12,4), date(2026,10,28))
        r = compute(L, at(date(2026,12,4),12), next_payday=date(2026,12,3))
        self.assertEqual(r.state,'awaiting_payday')

    def test_no_end_cycle_cap_even_with_spending_history(self):
        L = make_ledger(11000, date(2026,11,27), date(2026,10,28))
        for i in range(30):
            spend(L, 500, at(date(2026,10,28)+timedelta(days=i),14))
        r = compute(L, at(date(2026,11,27),12), next_payday=date(2026,11,28))
        self.assertEqual(r.display_allowance_today, rupees(11000))
        self.assertEqual(r.surplus_above_cap,0)
        self.assertNotIn('parked',kivi_says(r))

    def test_optional_reserve_can_change_or_be_removed(self):
        L = make_ledger(20000,date(2026,11,18),date(2026,10,28))
        as_of=at(date(2026,11,18),12)
        base=compute(L,as_of,next_payday=date(2026,11,28))
        saved=compute(L,as_of,next_payday=date(2026,11,28),cfg=replace(DEFAULT,emergency_reserve_paise=rupees(5000)))
        restored=compute(L,as_of,next_payday=date(2026,11,28),cfg=replace(DEFAULT,emergency_reserve_paise=0))
        self.assertEqual((base.allowance_today,saved.allowance_today,restored.allowance_today),
                         (rupees(2000),rupees(1500),rupees(2000)))

    def test_identical_amount_time_across_sources_does_not_merge_without_reference(self):
        L=make_ledger(20000,date(2026,11,18),date(2026,10,28))
        t=at(date(2026,11,18),12)
        a=L.ingest(RawEvent('sms','sms-a','SB1','debit',rupees(100),t,Kind.SPEND))
        b=L.ingest(RawEvent('aa','aa-b','SB1','debit',rupees(100),t,Kind.SPEND))
        self.assertEqual((a.status,b.status),('new','new'))
