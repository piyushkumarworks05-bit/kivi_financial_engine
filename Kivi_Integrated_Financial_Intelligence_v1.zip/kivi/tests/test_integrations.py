import tempfile,unittest
from datetime import datetime,date,timedelta
from pathlib import Path
from kivi_engine.storage import Store
from kivi_engine.ledger import Account,AcctType,RawEvent,Kind,Commitment
from kivi_engine.config import IST
from kivi_engine.sms import parse_sms
from kivi_engine.service import dashboard
from kivi_engine.analytics import suspected_recurring
from kivi_engine.reconciliation import potential_duplicates

T=lambda d:datetime.fromisoformat(d).replace(tzinfo=IST)
class IntegrationTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.path=Path(self.tmp.name)/'ledger.sqlite3';self.s=Store(self.path)
        self.s.account('alice',Account('bank',AcctType.SAVINGS));self.s.snapshot('alice','bank',T('2026-10-28T00:00:00'),6000000)
        self.s.event('alice',RawEvent('manual','salary','bank','credit',6000000,T('2026-10-28T09:00:00'),Kind.SALARY))
        self.s.setting('alice','next_payday','2026-11-28');self.s.setting('alice','accounts_complete',True)
    def tearDown(self):self.s.close();self.tmp.cleanup()
    def test_persistence_and_user_isolation(self):
        self.s.close();self.s=Store(self.path)
        a,_,_,_=self.s.load('alice');b,_,_,_=self.s.load('bob')
        self.assertEqual(len(a.events),1);self.assertEqual(len(b.events),0)
    def test_idempotent_event(self):
        raw=RawEvent('sms','dup','bank','debit',10000,T('2026-10-29T12:00:00'),Kind.SPEND)
        self.assertTrue(self.s.event('alice',raw));self.assertFalse(self.s.event('alice',raw))
    def test_user_correction_audited(self):
        self.s.event('alice',RawEvent('sms','candidate','bank','credit',100000,T('2026-10-29T12:00:00'),Kind.INCOME,salary_candidate=True))
        self.s.correct('alice','sms','candidate',Kind.SALARY,'confirmed')
        ledger,*_=self.s.load('alice');self.assertEqual(ledger.events[-1].kind,Kind.SALARY);self.assertTrue(ledger.audit)
    def test_reserve_recalculates(self):
        now=T('2026-10-30T18:00:00')
        a=dashboard(self.s,'alice',now)['safe2spend']['capacity_now_paise']
        self.s.setting('alice','emergency_reserve_paise',500000)
        b=dashboard(self.s,'alice',now)['safe2spend']['capacity_now_paise']
        self.assertEqual(a-b,500000)
    def test_targets_do_not_reserve(self):
        now=T('2026-10-30T18:00:00');before=dashboard(self.s,'alice',now)['safe2spend']['capacity_now_paise']
        self.s.target('alice','food','Swiggy',300000,date(2026,10,1),date(2026,10,31))
        after=dashboard(self.s,'alice',now)
        self.assertEqual(before,after['safe2spend']['capacity_now_paise']);self.assertEqual(len(after['targets']),1)
    def test_duplicate_not_silently_merged(self):
        self.s.event('alice',RawEvent('sms','s1','bank','debit',5000,T('2026-10-30T11:00:00'),Kind.SPEND))
        self.s.event('alice',RawEvent('aa','a1','bank','debit',5000,T('2026-10-30T11:01:00'),Kind.SPEND))
        ledger,*_=self.s.load('alice');self.assertEqual(len(ledger.events),3)
        self.assertEqual(len(potential_duplicates(ledger)),1)
    def test_sms_debit(self):
        e=parse_sms('INR 450.00 debited from A/c 1234 to swiggy@icici UPI Ref 482911003412','bank',T('2026-10-30T10:00:00'))
        self.assertEqual(e.amount_paise,45000);self.assertEqual(e.ref,'482911003412')
    def test_sms_unknown_is_not_guessed(self):
        self.assertIsNone(parse_sms('Your OTP is 123456','bank',T('2026-10-30T10:00:00')))
    def test_recurring_is_suspected(self):
        for i,day in enumerate(['2026-08-01T09:00:00','2026-09-01T09:00:00']):
            self.s.event('alice',RawEvent('manual',str(i),'bank','debit',39900,T(day),Kind.SPEND,merchant='Netflix'))
        ledger,*_=self.s.load('alice');self.assertEqual(suspected_recurring(ledger,T('2026-10-30T10:00:00'))[0]['status'],'suspected_recurring')
if __name__=='__main__':unittest.main()
