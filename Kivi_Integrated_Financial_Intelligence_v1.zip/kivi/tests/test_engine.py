"""Acceptance tests: each encodes a row of the spec's acceptance matrix (see TRACEABILITY.md)."""
import unittest
from datetime import date, datetime, time, timedelta

from kivi_engine.aa_adapter import from_aa_txn, from_sms_debit
from kivi_engine.config import DEFAULT, IST
from kivi_engine.cycle import predict_next_payday, resolve_cycle
from kivi_engine.insights import food_delivery_pattern
from kivi_engine.ledger import Account, AcctType, Commitment, Kind, Ledger, RawEvent
from kivi_engine.money import fmt, rupees
from kivi_engine.runner import World
from kivi_engine.safe2spend import GoalAllocation, compute
from kivi_engine.simulator import PERSONAS, Simulator
from kivi_engine.voice import kivi_says, tone


def at(d, h=0, m=0, s=0):
    return datetime.combine(d, time(h, m, s), tzinfo=IST)


def R(amount, **kw):  # amount in rupees
    return rupees(amount)


def make_ledger(balance, snap_day, salary_day, salary_amt=40_000, extra_accounts=()):
    """Ledger with one salary account snapshot at 00:00 on snap_day, and a confirmed salary on salary_day."""
    L = Ledger()
    L.add_account(Account("SB1", AcctType.SAVINGS))
    for a in extra_accounts:
        L.add_account(a)
    L.add_snapshot("SB1", at(snap_day), rupees(balance))
    L.ingest(RawEvent("manual", f"sal-{salary_day}", "SB1", "credit", rupees(salary_amt),
                      at(salary_day, 0, 0, 0), Kind.SALARY))
    return L


_n = [0]


def spend(L, amount, ts, merchant=None, source="aa", ref=None, kind=Kind.SPEND, account="SB1", category=None):
    _n[0] += 1
    return L.ingest(RawEvent(source, f"t{_n[0]}", account, "debit", rupees(amount), ts, kind,
                             merchant=merchant, category=category, ref=ref))


class TestCycle(unittest.TestCase):
    def test_oct28_to_nov28_spans_31_days_no_reset_on_nov1(self):
        c = resolve_cycle([date(2026, 10, 28)], date(2026, 11, 1), next_expected=date(2026, 11, 28))
        self.assertEqual((c.start, c.last_day, c.total_days), (date(2026, 10, 28), date(2026, 11, 27), 31))
        self.assertEqual(c.days_remaining(date(2026, 11, 1)), 27)
        c28 = resolve_cycle([date(2026, 10, 28)], date(2026, 10, 28), date(2026, 11, 28))
        self.assertEqual(c28.days_remaining(date(2026, 10, 28)), 31)   # not 4

    def test_salary_on_5th_runs_to_4th(self):
        c = resolve_cycle([date(2026, 10, 5)], date(2026, 10, 20), date(2026, 11, 5))
        self.assertEqual(c.last_day, date(2026, 11, 4))

    def test_jan31_with_confirmed_feb28_boundary(self):
        c = resolve_cycle([date(2027, 1, 31)], date(2027, 2, 1), next_expected=date(2027, 2, 28))
        self.assertEqual(c.end_exclusive, date(2027, 2, 28))
        self.assertEqual(c.end_provenance, "confirmed_forecast")

    def test_payday_31_prediction_clamps_incl_leap_year(self):
        self.assertEqual(predict_next_payday(date(2027, 1, 31), 31), date(2027, 2, 28))
        self.assertEqual(predict_next_payday(date(2028, 1, 31), 31), date(2028, 2, 29))
        self.assertEqual(predict_next_payday(date(2026, 12, 28)), date(2027, 1, 28))

    def test_early_salary_starts_new_cycle_on_observed_date(self):
        c = resolve_cycle([date(2026, 10, 28), date(2026, 11, 26)], date(2026, 11, 26), date(2026, 12, 28))
        self.assertEqual(c.start, date(2026, 11, 26))
        self.assertEqual(c.start_provenance, "observed")

    def test_no_confirmed_salary_means_no_cycle(self):
        self.assertIsNone(resolve_cycle([], date(2026, 11, 1)))


class TestSafe2Spend(unittest.TestCase):
    def test_mid_cycle_signup_uses_current_balance_not_salary(self):
        L = make_ledger(9_000, date(2026, 11, 12), date(2026, 10, 28))
        rent = Commitment("rent", "Rent", rupees(4_000), date(2026, 11, 20))
        r = compute(L, at(date(2026, 11, 12), 10), [rent], next_payday=date(2026, 11, 28))
        self.assertEqual(r.capacity_now, rupees(5_000))
        self.assertEqual(r.days_remaining, 16)
        self.assertEqual(r.allowance_today, rupees(312))          # 5000/16 = 312.5 -> floor to rupee
        self.assertEqual(r.confidence, "verified")

    def test_rolling_overspend_200_plan_500_spend_5_days_left(self):
        L = make_ledger(1_200, date(2026, 11, 22), date(2026, 11, 22))
        before = compute(L, at(date(2026, 11, 22), 9), [], next_payday=date(2026, 11, 28))
        self.assertEqual((before.days_remaining, before.allowance_today), (6, rupees(200)))
        spend(L, 500, at(date(2026, 11, 22), 14))
        r = compute(L, at(date(2026, 11, 22), 15), [], next_payday=date(2026, 11, 28))
        self.assertEqual(r.allowance_today, rupees(200))          # today's number is not rewritten
        self.assertEqual(r.left_today, -rupees(300))
        self.assertEqual(r.next_day_allowance, rupees(140))       # 200 - 60

    def test_underspend_carries_forward(self):
        L = make_ledger(1_200, date(2026, 11, 22), date(2026, 11, 22))
        spend(L, 100, at(date(2026, 11, 22), 14))
        r = compute(L, at(date(2026, 11, 22), 15), [], next_payday=date(2026, 11, 28))
        self.assertEqual(r.next_day_allowance, rupees(220))       # 1100 / 5

    def test_already_paid_debit_in_snapshot_not_subtracted_twice(self):
        L = make_ledger(1_200, date(2026, 11, 23), date(2026, 11, 22))   # snapshot already reflects Nov 22 spend
        spend(L, 500, at(date(2026, 11, 22), 14))                         # same debit arrives late (SMS)
        r = compute(L, at(date(2026, 11, 23), 9), [], next_payday=date(2026, 11, 28))
        self.assertEqual(r.capacity_now, rupees(1_200))

    def test_debit_after_snapshot_is_applied_exactly_once(self):
        L = make_ledger(5_000, date(2026, 11, 23), date(2026, 11, 20))
        a = compute(L, at(date(2026, 11, 23), 20), [], next_payday=date(2026, 11, 28))
        spend(L, 400, at(date(2026, 11, 23), 8), source="sms")   # after the 00:00 snapshot, so it applies once
        b = compute(L, at(date(2026, 11, 23), 20), [], next_payday=date(2026, 11, 28))
        self.assertEqual(b.capacity_now, a.capacity_now - rupees(400))   # applied exactly once
        self.assertEqual(b.spent_today, rupees(400))

    def test_paid_rent_not_reserved_unpaid_rent_is(self):
        L = make_ledger(20_000, date(2026, 11, 1), date(2026, 10, 28))
        rent = Commitment("rent-1", "Rent", rupees(12_000), date(2026, 11, 1))
        emi = Commitment("emi-1", "EMI", rupees(2_000), date(2026, 11, 5))
        L.ingest(RawEvent("aa", "rentpay", "SB1", "debit", rupees(12_000), at(date(2026, 11, 1), 11),
                          Kind.OBLIGATION_PAYMENT, commitment_id="rent-1"))
        r = compute(L, at(date(2026, 11, 1), 12), [rent, emi], next_payday=date(2026, 11, 28))
        self.assertEqual(r.breakdown["obligations_total"], rupees(2_000))          # only the EMI
        self.assertEqual(r.capacity_now, rupees(20_000 - 12_000 - 2_000))          # rent deducted once
        # after the EMI is paid it is no longer reserved
        L.ingest(RawEvent("aa", "emipay", "SB1", "debit", rupees(2_000), at(date(2026, 11, 5), 9),
                          Kind.OBLIGATION_PAYMENT, commitment_id="emi-1"))
        r2 = compute(L, at(date(2026, 11, 5), 10), [rent, emi], next_payday=date(2026, 11, 28))
        self.assertEqual(r2.breakdown["obligations_total"], 0)
        self.assertEqual(r2.capacity_now, rupees(6_000))

    def test_obligation_due_after_cycle_not_reserved(self):
        L = make_ledger(10_000, date(2026, 11, 1), date(2026, 10, 28))
        later = Commitment("x", "Later bill", rupees(5_000), date(2026, 11, 28))
        r = compute(L, at(date(2026, 11, 1), 12), [later], next_payday=date(2026, 11, 28))
        self.assertEqual(r.breakdown["obligations_total"], 0)

    def test_goal_increase_by_1000_lowers_capacity_by_1000(self):
        L = make_ledger(20_000, date(2026, 11, 1), date(2026, 10, 28))
        a = compute(L, at(date(2026, 11, 1), 12), [], [GoalAllocation("bike", "Bike", rupees(2_000))],
                    date(2026, 11, 28))
        b = compute(L, at(date(2026, 11, 1), 12), [], [GoalAllocation("bike", "Bike", rupees(3_000))],
                    date(2026, 11, 28))
        self.assertEqual(a.capacity_now - b.capacity_now, rupees(1_000))
        self.assertLess(b.allowance_today, a.allowance_today)

    def test_goal_contribution_already_transferred_not_deducted_twice(self):
        goal = [GoalAllocation("bike", "Bike", rupees(3_000))]
        L = make_ledger(20_000, date(2026, 11, 1), date(2026, 10, 28))
        reserved = compute(L, at(date(2026, 11, 1), 12), [], goal, date(2026, 11, 28))
        L.ingest(RawEvent("aa", "gt", "SB1", "debit", rupees(3_000), at(date(2026, 11, 1), 13),
                          Kind.TRANSFER_OWN, goal_id="bike", counterparty_account_id="GOAL:BIKE"))
        funded = compute(L, at(date(2026, 11, 1), 14), [], goal, date(2026, 11, 28))
        self.assertEqual(reserved.capacity_now, rupees(17_000))
        self.assertEqual(funded.capacity_now, rupees(17_000))              # 3,000 once, not 6,000
        self.assertEqual(funded.breakdown["goals_reserved"], 0)
        self.assertEqual(funded.spent_today, 0)                            # moving to a goal is not spending

    def test_unapproved_goal_not_protected(self):
        L = make_ledger(20_000, date(2026, 11, 1), date(2026, 10, 28))
        r = compute(L, at(date(2026, 11, 1), 12), [], [GoalAllocation("b", "B", rupees(5_000), approved=False)],
                    date(2026, 11, 28))
        self.assertEqual(r.breakdown["goals_reserved"], 0)

    def test_shortfall_is_explicit_never_green(self):
        L = make_ledger(3_000, date(2026, 11, 10), date(2026, 10, 28))
        rent = Commitment("rent", "Rent", rupees(5_000), date(2026, 11, 15))
        r = compute(L, at(date(2026, 11, 10), 12), [rent], next_payday=date(2026, 11, 28))
        self.assertEqual((r.state, r.shortfall, r.allowance_today), ("shortfall", rupees(2_000), 0))

    def test_stale_balance_is_labeled_estimated(self):
        L = make_ledger(9_000, date(2026, 11, 5), date(2026, 10, 28))
        r = compute(L, at(date(2026, 11, 9), 12), [], next_payday=date(2026, 11, 28))
        self.assertEqual(r.confidence, "estimated")
        self.assertTrue(any("old" in n for n in r.notes))

    def test_predicted_payday_is_labeled_estimated(self):
        L = make_ledger(9_000, date(2026, 11, 5), date(2026, 10, 28))
        r = compute(L, at(date(2026, 11, 5), 12), [], usual_payday_day=28)
        self.assertEqual(r.confidence, "estimated")

    def test_incomplete_account_coverage_lowers_confidence(self):
        L = make_ledger(9_000, date(2026, 11, 5), date(2026, 10, 28))
        r = compute(L, at(date(2026, 11, 5), 12), [], next_payday=date(2026, 11, 28), accounts_complete=False)
        self.assertEqual(r.confidence, "estimated")

    def test_missing_balance_gives_no_number(self):
        L = Ledger()
        L.add_account(Account("SB1", AcctType.SAVINGS))
        L.ingest(RawEvent("manual", "s", "SB1", "credit", 100, at(date(2026, 10, 28)), Kind.SALARY))
        r = compute(L, at(date(2026, 11, 5), 12), [], next_payday=date(2026, 11, 28))
        self.assertEqual((r.state, r.allowance_today), ("insufficient", 0))

    def test_unconfirmed_salary_credit_does_not_reset_cycle_or_inflate_number(self):
        L = make_ledger(5_000, date(2026, 11, 28), date(2026, 10, 28))
        cand = L.ingest(RawEvent("aa", "big", "SB1", "credit", rupees(40_000), at(date(2026, 11, 28), 9),
                                 Kind.INCOME, salary_candidate=True))
        r = compute(L, at(date(2026, 11, 28), 12), [], next_payday=date(2026, 11, 28))
        self.assertEqual(r.cycle.start, date(2026, 10, 28))               # no automatic reset
        self.assertEqual(r.state, "awaiting_payday")  # no number until revised payday
        self.assertEqual(r.allowance_today, 0)
        self.assertEqual(r.confidence, "estimated")
        L.confirm_salary(cand.event_id)
        r2 = compute(L, at(date(2026, 11, 28), 12), [], next_payday=date(2026, 12, 28))
        self.assertEqual((r2.cycle.start, r2.days_remaining), (date(2026, 11, 28), 30))
        self.assertEqual(r2.capacity_now, rupees(45_000))
        self.assertEqual(L.audit[-1]["new"], "salary")                    # change is audited, evidence kept

    def test_refund_linked_to_purchase_nets_spend_unlinked_is_flagged(self):
        L = make_ledger(5_000, date(2026, 11, 10), date(2026, 10, 28))
        orig = spend(L, 800, at(date(2026, 11, 9), 14), merchant="Myntra")
        ref = L.ingest(RawEvent("aa", "rf", "SB1", "credit", rupees(800), at(date(2026, 11, 10), 12),
                                Kind.REFUND))
        r = compute(L, at(date(2026, 11, 10), 13), [], next_payday=date(2026, 11, 28))
        self.assertTrue(any("not linked" in n for n in r.notes))
        L.link_refund(ref.event_id, orig.event_id)
        r2 = compute(L, at(date(2026, 11, 10), 13), [], next_payday=date(2026, 11, 28))
        self.assertEqual(r2.spent_today, -rupees(800))                    # money came back today
        self.assertFalse(any("not linked" in n for n in r2.notes))
        self.assertEqual(r2.capacity_now, rupees(5_800))


class TestReconciliation(unittest.TestCase):
    def test_replay_of_same_source_event_is_idempotent(self):
        L = make_ledger(5_000, date(2026, 11, 10), date(2026, 10, 28))
        raw = RawEvent("sms", "same", "SB1", "debit", rupees(450), at(date(2026, 11, 10), 12), Kind.SPEND)
        self.assertEqual(L.ingest(raw).status, "new")
        self.assertEqual(L.ingest(raw).status, "replay")
        self.assertEqual(len([e for e in L.events if e.kind == Kind.SPEND]), 1)

    def test_sms_and_aa_for_same_transaction_count_once(self):
        L = make_ledger(5_000, date(2026, 11, 10), date(2026, 10, 28))
        ts = at(date(2026, 11, 10), 12, 0)
        sms = from_sms_debit("Rs.450.00 debited from A/c XX1234 to VPA swiggy@icici. UPI Ref 482911003412",
                             "SB1", ts)
        aa = from_aa_txn({"txnId": "T9", "type": "DEBIT", "mode": "UPI", "amount": "450.00",
                          "transactionTimestamp": (ts + timedelta(minutes=3)).isoformat(),
                          "narration": "UPI/482911003412/SWIGGY/swiggy@icici", "reference": "482911003412"}, "SB1")
        self.assertEqual(L.ingest(sms).status, "new")
        self.assertEqual(L.ingest(aa).status, "merged")
        self.assertEqual(len([e for e in L.events if e.kind == Kind.SPEND]), 1)
        e = [e for e in L.events if e.kind == Kind.SPEND][0]
        self.assertEqual(len(e.evidence), 2)                               # both raw records kept
        r = compute(L, at(date(2026, 11, 10), 13), [], next_payday=date(2026, 11, 28))
        self.assertEqual(r.spent_today, rupees(450))

    def test_two_identical_purchases_from_same_source_are_two_events(self):
        L = make_ledger(5_000, date(2026, 11, 10), date(2026, 10, 28))
        spend(L, 50, at(date(2026, 11, 10), 12, 0))
        spend(L, 50, at(date(2026, 11, 10), 12, 5))
        self.assertEqual(compute(L, at(date(2026, 11, 10), 13), [], next_payday=date(2026, 11, 28)).spent_today,
                         rupees(100))

    def test_different_references_never_merge(self):
        L = make_ledger(5_000, date(2026, 11, 10), date(2026, 10, 28))
        spend(L, 450, at(date(2026, 11, 10), 12, 0), source="sms", ref="111111111111")
        spend(L, 450, at(date(2026, 11, 10), 12, 1), source="aa", ref="222222222222")
        self.assertEqual(len([e for e in L.events if e.kind == Kind.SPEND]), 2)

    def test_own_account_transfer_is_neither_spend_nor_income(self):
        sb2 = Account("SB2", AcctType.SAVINGS)
        L = make_ledger(10_000, date(2026, 11, 10), date(2026, 10, 28), extra_accounts=[sb2])
        L.add_snapshot("SB2", at(date(2026, 11, 10)), rupees(1_000))
        base = compute(L, at(date(2026, 11, 10), 9), [], next_payday=date(2026, 11, 28))
        L.ingest(RawEvent("aa", "o", "SB1", "debit", rupees(5_000), at(date(2026, 11, 10), 10), Kind.TRANSFER_OWN,
                          counterparty_account_id="SB2"))
        L.ingest(RawEvent("aa", "i", "SB2", "credit", rupees(5_000), at(date(2026, 11, 10), 10), Kind.TRANSFER_OWN,
                          counterparty_account_id="SB1"))
        r = compute(L, at(date(2026, 11, 10), 11), [], next_payday=date(2026, 11, 28))
        self.assertEqual((r.capacity_now, r.spent_today), (base.capacity_now, 0))
        self.assertEqual(r.allowance_today, base.allowance_today)

    def test_card_purchase_then_card_payment_counts_consumption_once(self):
        card = Account("CC1", AcctType.CARD)
        L = make_ledger(10_000, date(2026, 11, 10), date(2026, 10, 28), extra_accounts=[card])
        L.add_snapshot("CC1", at(date(2026, 11, 10)), 0)
        base = compute(L, at(date(2026, 11, 10), 9), [], next_payday=date(2026, 11, 28))
        spend(L, 2_000, at(date(2026, 11, 10), 12), kind=Kind.CARD_PURCHASE, account="CC1")
        r1 = compute(L, at(date(2026, 11, 10), 13), [], next_payday=date(2026, 11, 28))
        self.assertEqual(r1.capacity_now, base.capacity_now - rupees(2_000))   # reserved once, at purchase
        self.assertEqual(r1.spent_today, rupees(2_000))
        # payment: liquid leg + card-side leg
        L.ingest(RawEvent("aa", "p1", "SB1", "debit", rupees(2_000), at(date(2026, 11, 10), 15), Kind.CARD_PAYMENT,
                          counterparty_account_id="CC1"))
        L.ingest(RawEvent("aa", "p2", "CC1", "credit", rupees(2_000), at(date(2026, 11, 10), 15), Kind.CARD_PAYMENT,
                          counterparty_account_id="SB1"))
        r2 = compute(L, at(date(2026, 11, 10), 16), [], next_payday=date(2026, 11, 28))
        self.assertEqual(r2.capacity_now, r1.capacity_now)                     # payment changes nothing
        self.assertEqual(r2.spent_today, rupees(2_000))                        # and is not new consumption
        self.assertEqual(r2.breakdown["card_outstanding"], 0)

    def test_card_payment_with_only_liquid_leg_also_settles_once(self):
        card = Account("CC1", AcctType.CARD)
        L = make_ledger(10_000, date(2026, 11, 10), date(2026, 10, 28), extra_accounts=[card])
        L.add_snapshot("CC1", at(date(2026, 11, 10)), rupees(2_000))
        before = compute(L, at(date(2026, 11, 10), 9), [], next_payday=date(2026, 11, 28))
        L.ingest(RawEvent("sms", "only", "SB1", "debit", rupees(2_000), at(date(2026, 11, 10), 15),
                          Kind.CARD_PAYMENT, counterparty_account_id="CC1"))
        after = compute(L, at(date(2026, 11, 10), 16), [], next_payday=date(2026, 11, 28))
        self.assertEqual(after.capacity_now, before.capacity_now)

    def test_unknown_upi_debit_stays_unknown(self):
        raw = from_aa_txn({"txnId": "T1", "type": "DEBIT", "mode": "UPI", "amount": "450.00",
                           "transactionTimestamp": at(date(2026, 11, 10), 12).isoformat(),
                           "narration": "UPI/123456789012/RAMESH KUMAR/ramesh@okaxis"}, "SB1")
        self.assertEqual((raw.category, raw.kind), (None, Kind.SPEND))
        self.assertEqual(raw.merchant, "Ramesh Kumar")      # evidence of the PAYEE only, never the item

    def test_user_correction_persists_over_later_higher_ranked_source(self):
        L = make_ledger(5_000, date(2026, 11, 10), date(2026, 10, 28))
        r = spend(L, 450, at(date(2026, 11, 10), 12), source="sms", ref="9" * 12)
        L.reclassify(r.event_id, Kind.TRANSFER_OWN, "this was a transfer to my wife")
        L.ingest(RawEvent("aa", "later", "SB1", "debit", rupees(450), at(date(2026, 11, 10), 12, 1), Kind.SPEND,
                          ref="9" * 12))
        self.assertEqual(L.events[r.event_id - 1].kind, Kind.TRANSFER_OWN)
        self.assertEqual(len(L.audit), 1)

    def test_naive_timestamps_rejected(self):
        L = make_ledger(5_000, date(2026, 11, 10), date(2026, 10, 28))
        with self.assertRaises(ValueError):
            L.ingest(RawEvent("aa", "n", "SB1", "debit", 100, datetime(2026, 11, 10, 12), Kind.SPEND))

    def test_money_helpers(self):
        self.assertEqual(rupees("649.50"), 64950)
        self.assertEqual(fmt(rupees(1234567)), "₹12,34,567")
        self.assertEqual(fmt(-rupees(300)), "-₹300")


class TestKiviVoice(unittest.TestCase):
    def _delivery_ledger(self, n=4, late=True):
        L = make_ledger(20_000, date(2026, 11, 10), date(2026, 10, 28))
        L.add_snapshot("SB1", at(date(2026, 11, 12)), rupees(20_000))     # fresh balance (not stale)
        for i in range(n):
            spend(L, 450, at(date(2026, 11, 10 + (i % 3)), 23 if (late and i == 0) else 13, i),
                  merchant="Swiggy", category="food_delivery")
        return L

    def test_roast_is_evidence_based_and_never_invents_items(self):
        L = self._delivery_ledger()
        as_of = at(date(2026, 11, 12), 23, 59)
        p = food_delivery_pattern(L, as_of)
        self.assertEqual((p.orders, p.total_paise), (4, rupees(1_800)))
        res = compute(L, as_of, [], next_payday=date(2026, 11, 28))
        line = kivi_says(res, p)
        self.assertEqual(tone(res, p), "playful")
        self.assertIn("4 delivery orders", line)
        for banned in ("burger", "pizza", "biryani", "momo"):
            self.assertNotIn(banned, line.lower())

    def test_unknown_merchants_do_not_trigger_food_roast(self):
        L = make_ledger(20_000, date(2026, 11, 10), date(2026, 10, 28))
        for i in range(5):
            spend(L, 450, at(date(2026, 11, 10), 13, i), merchant="Ramesh Kumar")
        self.assertIsNone(food_delivery_pattern(L, at(date(2026, 11, 10), 23, 59)))

    def test_no_roast_during_distress_even_with_pattern(self):
        L = self._delivery_ledger()
        rent = Commitment("rent", "Rent", rupees(30_000), date(2026, 11, 15))
        as_of = at(date(2026, 11, 12), 23, 59)
        p = food_delivery_pattern(L, as_of)
        res = compute(L, as_of, [rent], next_payday=date(2026, 11, 28))
        self.assertEqual(res.state, "shortfall")
        self.assertEqual(tone(res, p), "distress")
        line = kivi_says(res, p).lower()
        self.assertNotIn("kitchen", line)
        self.assertNotIn("receipts", line)
        self.assertIn("options", line)

    def test_overdue_bill_triggers_supportive_tone(self):
        L = make_ledger(20_000, date(2026, 11, 10), date(2026, 10, 28))
        emi = Commitment("emi", "Phone EMI", rupees(2_000), date(2026, 11, 5))
        res = compute(L, at(date(2026, 11, 10), 12), [emi], next_payday=date(2026, 11, 28))
        self.assertEqual(tone(res, None), "distress")
        self.assertIn("Phone EMI", kivi_says(res, None))

    def test_estimated_numbers_are_called_estimates(self):
        L = make_ledger(9_000, date(2026, 11, 5), date(2026, 10, 28))
        res = compute(L, at(date(2026, 11, 9), 12), [], next_payday=date(2026, 11, 28))
        self.assertIn("estimate", kivi_says(res, None).lower())


class TestSimulatorEndToEnd(unittest.TestCase):
    @staticmethod
    def _prev_payday(persona, start=date(2026, 10, 22)):
        d = date(start.year, start.month, min(persona.payday_day, 28))
        return d if d < start else date(start.year, start.month - 1, min(persona.payday_day, 28))

    def _run(self, key, seed, days=40):
        w = World(PERSONAS[key], seed, date(2026, 10, 22), rupees(9_000), self._prev_payday(PERSONAS[key]))
        return w, [w.advance(date(2026, 10, 22) + timedelta(days=i)) for i in range(days)]

    def test_deterministic_for_same_seed(self):
        _, a = self._run("foodie", 5)
        _, b = self._run("foodie", 5)
        self.assertEqual([(v.result.allowance_today, v.result.spent_today) for v in a],
                         [(v.result.allowance_today, v.result.spent_today) for v in b])

    def test_cycle_crosses_month_boundary_without_reset_for_payday_28(self):
        for key in ("foodie", "stacked"):
            _, views = self._run(key, 11)
            by_day = {v.day: v.result for v in views}
            for d in (date(2026, 10, 31), date(2026, 11, 1), date(2026, 11, 2)):
                self.assertEqual(by_day[d].cycle.start, date(2026, 10, 28), key)
                self.assertEqual(by_day[d].cycle.last_day, date(2026, 11, 27), key)
            self.assertEqual(by_day[date(2026, 10, 28)].days_remaining, 31, key)
            self.assertEqual(by_day[date(2026, 11, 28)].cycle.start, date(2026, 11, 28), key)

    def test_every_cycle_starts_on_a_payday_and_contains_its_day(self):
        for key, p in PERSONAS.items():
            _, views = self._run(key, 3)
            for v in views:
                c = v.result.cycle
                self.assertTrue(c.start <= v.day < c.end_exclusive, (key, v.day))
                self.assertEqual(c.start.day, min(p.payday_day, 28), key)
                self.assertFalse(c.overdue, (key, v.day))
                self.assertIn(c.total_days, (28, 29, 30, 31))

    def test_invariants_over_many_seeds_and_personas(self):
        for key in PERSONAS:
            for seed in range(8):
                w, views = self._run(key, seed)
                for v in views:
                    r = v.result
                    self.assertGreaterEqual(r.allowance_today, 0)
                    self.assertEqual(r.allowance_today % 100, 0)                 # whole rupees
                    # the number is never above what the funds can support
                    self.assertLessEqual(r.allowance_today * r.days_remaining, max(r.capacity_start_of_day, 0))
                    self.assertIn(r.state, ("ok", "shortfall"))
                    self.assertEqual(len([e for e in w.ledger.events if e.kind == Kind.SALARY]) >= 1, True)
                # no duplicated economic events: every source_id seen maps to exactly one event
                ids = [(ev.source, ev.source_id) for e in w.ledger.events for ev in e.evidence]
                self.assertEqual(len(ids), len(set(ids)))

    def test_ledger_balance_tracks_simulated_bank_balance(self):
        w, views = self._run("foodie", 4)
        bal, _ = w.ledger.liquid_balance(datetime(2026, 12, 1, tzinfo=IST))
        # ledger = snapshot(00:00 last day) + that day's events; must equal the bank's own balance
        self.assertEqual(bal, w.sim.balance)

    def test_live_spend_button_updates_the_number(self):
        w, _ = self._run("foodie", 2, days=12)
        d = date(2026, 11, 2)
        before = w.view(at(d, 23, 59, 59))
        v = w.spend_now(rupees(500), "Zomato", at(d + timedelta(days=1), 13) )
        self.assertNotEqual(before.result.capacity_now, v.result.capacity_now)

    def test_roast_cooldown_prevents_daily_roasting(self):
        _, views = self._run("foodie", 1)
        roasts = [v for v in views if "delivery" in v.line and v.result.state == "ok"]
        gaps = [(b.day - a.day).days for a, b in zip(roasts, roasts[1:])]
        self.assertTrue(all(g >= DEFAULT.roast_cooldown_days for g in gaps), gaps)


