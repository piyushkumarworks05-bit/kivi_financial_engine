"""Run a simulated user through a salary cycle and print what Kivi would show each day.

    python3 demo.py                     # foodie persona, 22 Oct -> 30 Nov 2026
    python3 demo.py stacked 7           # other persona / seed
"""
import sys
from datetime import date, timedelta

from kivi_engine.money import fmt
from kivi_engine.runner import World
from kivi_engine.simulator import PERSONAS

key = sys.argv[1] if len(sys.argv) > 1 else "foodie"
seed = int(sys.argv[2]) if len(sys.argv) > 2 else 1
persona = PERSONAS[key]
start = date(2026, 10, 22)
w = World(persona, seed, start, opening_balance_paise=9_000_00, prev_salary_date=date(2026, 9, 28))

print(f"Persona: {persona.name} | seed {seed} | demo data, not real AA data")
print("Assumes the user confirmed each salary credit and the next payday.\n")
print(f"{'date':<8}{'cycle':<14}{'days':>4}  {'today':>8} {'spent':>8} {'left':>8} {'tomorrow':>9}  state/confidence")
for i in range(40):
    d = start + timedelta(days=i)
    v = w.advance(d)
    r = v.result
    cyc = f"{r.cycle.start:%d%b}-{r.cycle.last_day:%d%b}" if r.cycle else "-"
    nxt = fmt(r.display_next_day_allowance) if r.display_next_day_allowance is not None else "-"
    print(f"{d:%d %b}  {cyc:<14}{r.days_remaining:>4}  {fmt(r.display_allowance_today):>8} {fmt(r.spent_today):>8} "
          f"{fmt(r.display_left_today):>8} {nxt:>9}  {r.state}/{r.confidence}"
          + (f"  parked {fmt(r.surplus_above_cap)}" if r.surplus_above_cap else ""))
    if i % 3 == 0 or r.state != "ok" or v.pattern:
        print(f"        Kivi: {v.line}")
print("\nEvents:", *w.log, sep="\n  ")
