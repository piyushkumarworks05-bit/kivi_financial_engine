"""Every product decision the spec marks as OPEN lives here, with a labeled default.

These defaults are ENGINEERING ASSUMPTIONS, not founder decisions. Change them here only.
"""
from dataclasses import dataclass
from datetime import timedelta, timezone

# India has no DST, so a fixed offset is exact and deterministic.
IST = timezone(timedelta(hours=5, minutes=30))


@dataclass(frozen=True)
class Config:
    # OPEN: rounding policy. Default: floor allowances to whole rupees (conservative).
    allowance_rounding_paise: int = 100
    # OPEN: balance staleness. Older than this -> result is labeled "estimated".
    stale_after_hours: int = 48
    # OPEN: minimum emergency reserve default. Default: none.
    emergency_reserve_paise: int = 0
    # Cross-source dedupe window when no shared reference exists.
    dedupe_window_minutes: int = 15
    # Late-night window for roast evidence: [start_hour, 24) and [0, end_hour).
    late_night_start_hour: int = 23
    late_night_end_hour: int = 5
    # Food-delivery pattern thresholds for roast eligibility.
    food_pattern_window_days: int = 7
    food_pattern_min_orders: int = 3
    # OPEN: push cadence. Roast at most once per N days (a product-feel default, tune with users).
    roast_cooldown_days: int = 3
    # OPEN: time-of-day proration. Default: none (full allowance available until midnight IST).
    # APPROVED: No automatic late-salary horizon; ask for a revised payday.
    # APPROVED: No arbitrary daily-allowance cap.
    # APPROVED: Optional emergency reserve, default zero, configured by user.
DEFAULT = Config()
