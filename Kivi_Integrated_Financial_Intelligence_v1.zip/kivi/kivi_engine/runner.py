"""Glue: simulator -> AA adapter -> ledger -> Safe 2 Spend -> Kivi. Used by the demo, tests and (later) the API."""
from __future__ import annotations

from dataclasses import dataclass
from datetime import date, datetime, time, timedelta

from .aa_adapter import from_aa_txn
from .config import DEFAULT, IST
from .cycle import predict_next_payday
from .insights import FoodPattern, food_delivery_pattern
from .ledger import Account, AcctType, Kind, Ledger, RawEvent, local_date
from .safe2spend import GoalAllocation, Result, compute
from .simulator import Persona, Simulator, commitments_between, resolver_for
from .voice import kivi_says


def at(d: date, h=0, m=0, s=0) -> datetime:
    return datetime.combine(d, time(h, m, s), tzinfo=IST)


@dataclass
class DayView:
    day: date
    result: Result
    pattern: FoodPattern | None
    line: str
    notes: list


class World:
    """One simulated user. `advance(day)` plays a day; `spend_now(...)` is the live 'I just spent' button."""

    def __init__(self, persona: Persona, seed: int, start: date, opening_balance_paise: int,
                 prev_salary_date: date, cfg=DEFAULT):
        self.persona, self.cfg, self.start = persona, cfg, start
        self.sim = Simulator(persona, seed, opening_balance_paise)
        self.ledger = Ledger(cfg)
        for a in (Account("SB1", AcctType.SAVINGS, "Salary account"), Account("CC1", AcctType.CARD, "Credit card"),
                  Account("GOAL1", AcctType.GOAL, "Goal pot")):
            self.ledger.add_account(a)
        self.ledger.add_snapshot("SB1", at(start), opening_balance_paise, "aa")
        self.ledger.add_snapshot("CC1", at(start), 0, "aa")
        r = self.ledger.ingest(RawEvent("manual", "prev-salary", "SB1", "credit", persona.salary_paise,
                                        at(prev_salary_date, 9), Kind.SALARY))
        self.commitments = commitments_between(persona, start, start + timedelta(days=120))
        self.goals = ([GoalAllocation(persona.goal_key, persona.goal_key, persona.goal_amount_paise)]
                      if persona.goal_key else [])
        self.resolver = resolver_for(persona)
        self.log: list[str] = []
        self._last_roast: date | None = None

    def _ingest_txn(self, account_id: str, txn: dict) -> None:
        raw = from_aa_txn(txn, account_id, self.resolver, is_card=(account_id == "CC1"))
        res = self.ledger.ingest(raw)
        if res.status == "new" and raw.salary_candidate:
            self.ledger.confirm_salary(res.event_id)           # stands in for the user tapping "yes, salary"
            self.log.append(f"{local_date(raw.ts)}: user confirmed salary credit")

    def next_payday(self, as_of: datetime) -> date:
        start = max(self.ledger.confirmed_salary_dates(as_of))
        return predict_next_payday(start, self.persona.payday_day)      # stands in for the user's confirmed date

    def view(self, as_of: datetime, seed: int = 0) -> DayView:
        res = compute(self.ledger, as_of, self.commitments, self.goals, self.next_payday(as_of),
                      self.persona.payday_day, True, self.cfg)
        pattern = food_delivery_pattern(self.ledger, as_of, self.cfg)
        today = local_date(as_of)
        quiet = (self._last_roast is not None
                 and 0 <= (today - self._last_roast).days < self.cfg.roast_cooldown_days
                 and today != self._last_roast)
        shown = None if quiet else pattern
        line = kivi_says(res, shown, seed)
        if shown is not None and res.state == "ok" and res.confidence == "verified":
            self._last_roast = today
        return DayView(today, res, pattern, line, res.notes)

    def advance(self, d: date) -> DayView:
        self.ledger.add_snapshot("SB1", at(d), self.sim.balance, "aa")
        for acct, txn in self.sim.day_events(d):
            self._ingest_txn(acct, txn)
        return self.view(at(d, 23, 59, 59), seed=d.toordinal())

    def spend_now(self, amount_paise: int, merchant: str, ts: datetime) -> DayView:
        self._ingest_txn("SB1", self.sim.spend_now(amount_paise, merchant, ts))
        return self.view(ts, seed=ts.toordinal())
