"""Safe 2 Spend. Deterministic, explainable, never double-deducts.

capacity_now = liquid balance (already reflects every past debit)
             - card outstanding            (owed, not yet paid)
             - unpaid commitments due before the next payday
             - approved goal allocations not yet moved into the goal
             - emergency reserve (config)
             - credits that look like salary but are unconfirmed (not spendable until confirmed)

capacity_start_of_day = capacity_now + today's net spend   (what we had before today's spending)
allowance_today       = floor(capacity_start_of_day / days_remaining_including_today)
next_day_allowance    = floor(capacity_now / (days_remaining - 1))   <- over/underspend rolls forward

If payday has passed without a confirmed salary, return awaiting_payday without
presenting a spendable allowance. A user-supplied future revised date is used
as an estimated forecast, not as a confirmed salary credit.
No arbitrary cap is applied to the displayed allowance.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime

from .config import Config, DEFAULT, IST
from .cycle import Cycle, resolve_cycle
from .ledger import Commitment, Ledger, local_date
from .money import floor_to


@dataclass(frozen=True)
class GoalAllocation:
    goal_id: str
    name: str
    amount_paise: int
    approved: bool = True


@dataclass
class Result:
    state: str                  # "ok" | "shortfall" | "insufficient" | "awaiting_payday"
    confidence: str             # "verified" | "estimated"
    as_of: datetime
    cycle: Cycle | None = None
    days_remaining: int = 0
    allowance_today: int = 0
    spent_today: int = 0
    left_today: int = 0         # may be negative when overspent
    next_day_allowance: int | None = None
    capacity_start_of_day: int = 0
    capacity_now: int = 0
    shortfall: int = 0
    breakdown: dict = field(default_factory=dict)
    overdue_obligations: list = field(default_factory=list)
    notes: list = field(default_factory=list)
    balance_age_hours: float | None = None
    # UI allowance always equals the uncapped calculated allowance.
    display_allowance_today: int = 0
    display_next_day_allowance: int | None = None
    surplus_above_cap: int = 0  # legacy compatibility field; always zero
    display_left_today: int = 0
    dipped_into_surplus: int = 0  # legacy compatibility field; always zero


def compute(ledger: Ledger, as_of: datetime, commitments=(), goals=(), next_payday=None,
            usual_payday_day: int | None = None, accounts_complete: bool = True,
            cfg: Config = DEFAULT) -> Result:
    notes: list[str] = []
    today = local_date(as_of)

    cycle = resolve_cycle(ledger.confirmed_salary_dates(as_of), today, next_payday, usual_payday_day)
    balance, oldest_snap = ledger.liquid_balance(as_of)
    if cycle is None or balance is None:
        why = "no confirmed salary yet" if cycle is None else "no balance snapshot yet"
        return Result("insufficient", "estimated", as_of, cycle, notes=[f"Cannot compute: {why}."])

    # An overdue expected date is not a license to invent another payday.
    # Do not display a number until the user provides a future revised date.
    if cycle.overdue:
        return Result("awaiting_payday", "estimated", as_of, cycle,
                      notes=["Your expected salary has not arrived. What is your revised expected payday?"],
                      breakdown={"liquid_balance": balance},
                      balance_age_hours=(as_of - oldest_snap).total_seconds() / 3600)

    estimated = False
    if cycle.end_provenance == "predicted":
        estimated = True
        notes.append(f"Next payday is a prediction ({cycle.end_exclusive}); confirm it for a firmer number.")
    age_h = (as_of - oldest_snap).total_seconds() / 3600
    if age_h > cfg.stale_after_hours:
        estimated = True
        notes.append(f"Balance data is {age_h:.0f}h old.")
    if not accounts_complete:
        estimated = True
        notes.append("Not all accounts are linked; the number only reflects linked accounts.")
    missing = ledger.accounts_without_snapshot(as_of)
    if missing:
        estimated = True
        notes.append(f"No balance for account(s): {', '.join(missing)}.")

    # Unconfirmed salary-like credits are in the balance but must not be spendable yet.
    pending = ledger.pending_salary_candidates(as_of)
    pending_amt = sum(e.amount_paise for e in pending if local_date(e.ts) >= cycle.start)
    if pending_amt:
        estimated = True
        notes.append("A credit that looks like salary is unconfirmed and is NOT counted as spendable.")

    card_out = ledger.card_outstanding(as_of)

    # Reserve unpaid bills due strictly before the expected next payday.
    horizon_end = cycle.end_exclusive
    obligations, overdue = [], []
    for c in commitments:
        remaining = c.amount_paise - ledger.commitment_paid(c.id, as_of)
        if remaining > 0 and c.due < horizon_end:     # unpaid and due before the horizon ends
            obligations.append((c.id, c.name, c.due, remaining))
            if c.due < today:
                overdue.append((c.name, c.due, remaining))
    obligations_total = sum(o[3] for o in obligations)

    goals_reserved = 0
    for g in goals:
        if g.approved:
            funded = ledger.goal_funded_since(g.goal_id, cycle.start, as_of)
            goals_reserved += max(0, g.amount_paise - funded)

    capacity_now = (balance - card_out - obligations_total - goals_reserved
                    - cfg.emergency_reserve_paise - pending_amt)
    spent_today = ledger.net_spend_on(today, as_of)
    capacity_start = capacity_now + spent_today
    days = cycle.days_remaining(today)
    allowance = floor_to(max(capacity_start, 0) // days, cfg.allowance_rounding_paise)
    nxt = (floor_to(max(capacity_now, 0) // (days - 1), cfg.allowance_rounding_paise)
           if days > 1 else None)
    shortfall = max(0, -capacity_now)

    # The displayed allowance is always the actual calculated allowance.
    shown = allowance
    shown_next = nxt
    surplus = 0
    dipped = 0
    shown_left = allowance - spent_today

    if ledger.unlinked_refunds(as_of):
        notes.append("A refund is not linked to its original purchase; please review.")

    return Result(
        state="shortfall" if shortfall > 0 else "ok",
        confidence="estimated" if estimated else "verified",
        as_of=as_of, cycle=cycle, days_remaining=days,
        allowance_today=0 if shortfall else allowance, spent_today=spent_today,
        left_today=(0 if shortfall else allowance) - spent_today,
        next_day_allowance=0 if shortfall else nxt,
        capacity_start_of_day=capacity_start, capacity_now=capacity_now, shortfall=shortfall,
        breakdown={"liquid_balance": balance, "card_outstanding": card_out,
                   "unpaid_obligations": obligations, "obligations_total": obligations_total,
                   "goals_reserved": goals_reserved, "emergency_reserve": cfg.emergency_reserve_paise,
                   "unconfirmed_credits_excluded": pending_amt},
        overdue_obligations=overdue, notes=notes, balance_age_hours=age_h,
        display_allowance_today=0 if shortfall else shown,
        display_next_day_allowance=0 if shortfall else shown_next,
        surplus_above_cap=0 if shortfall else surplus,
        display_left_today=0 if shortfall else shown_left,
        dipped_into_surplus=0 if shortfall else dipped)


