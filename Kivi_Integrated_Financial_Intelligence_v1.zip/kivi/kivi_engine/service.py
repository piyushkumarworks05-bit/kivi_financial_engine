"""App-facing financial service; all user state is scoped to an explicit user ID."""
from __future__ import annotations
from dataclasses import asdict
from datetime import date,datetime
from .storage import Store
from .safe2spend import compute
from .config import Config
from .analytics import spending_summary,spending_targets,suspected_recurring
from .reconciliation import balance_discrepancies,potential_duplicates
from .intelligence import tracker,spending,obligations,ghost_candidates,roast_facts,target_progress,goal_forecast

def dashboard(store:Store,user:str,as_of:datetime):
    ledger,commitments,goals,targets=store.load(user)
    next_date=store.get_setting(user,'next_payday')
    payday_day=store.get_setting(user,'payday_day')
    reserve=int(store.get_setting(user,'emergency_reserve_paise',0))
    if reserve<0:raise ValueError('negative reserve')
    cfg=Config(emergency_reserve_paise=reserve)
    result=compute(ledger,as_of,commitments,goals,date.fromisoformat(next_date) if next_date else None,
                   payday_day,store.get_setting(user,'accounts_complete',False),cfg)
    d=as_of.date()
    start=result.cycle.start if result.cycle else d.replace(day=1)
    end=result.cycle.end_exclusive if result.cycle else d
    goal_rows=[{'id':g.goal_id,'name':g.name,'approved':g.approved,'allocation_paise':g.amount_paise} for g in goals]
    return {'safe2spend':_result(result),'financial_tracker':tracker(ledger,as_of),
            'spending_intelligence':spending(ledger,start,d,as_of,store.get_setting(user,'monthly_salary_paise')),
            'upcoming_obligations':obligations(commitments,ledger,as_of,end),
            'goals':goal_rows,'roast_receipt':roast_facts(ledger,start,d,as_of),
            'ghost_purchases':ghost_candidates(ledger,as_of),'conversational_targets':target_progress(ledger,targets,as_of),
            'spending':spending_summary(ledger,d.replace(day=1),d,as_of),
            'targets':spending_targets(ledger,targets,as_of),'suspected_recurring':suspected_recurring(ledger,as_of),
            'data_quality':{**balance_discrepancies(ledger,as_of),'possible_duplicates':potential_duplicates(ledger)}}

def _result(r):
    return {'state':r.state,'confidence':r.confidence,'allowance_today_paise':r.allowance_today,
            'spent_today_paise':r.spent_today,'left_today_paise':r.left_today,
            'capacity_now_paise':r.capacity_now,'days_remaining':r.days_remaining,
            'notes':r.notes,'breakdown':r.breakdown,
            'next_payday':r.cycle.end_exclusive.isoformat() if r.cycle else None}
