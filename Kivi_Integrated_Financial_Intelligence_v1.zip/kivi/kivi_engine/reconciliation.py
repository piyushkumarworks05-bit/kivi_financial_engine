"""Conservative transaction ingestion and evidence-based reconciliation.

Only exact bank references permit cross-source merging; uncertain matches are review
candidates, never silently collapsed. Incoming data is evidence, not proof of a merchant.
"""
from __future__ import annotations
from datetime import datetime
from .aa_adapter import from_aa_txn
from .ledger import Ledger, RawEvent, Kind
from .storage import Store


def ingest_aa(store: Store, user: str, account_id: str, transactions: list[dict], *, is_card=False):
    accepted=0; rejected=[]
    for index, txn in enumerate(transactions):
        try:
            raw=from_aa_txn(txn,account_id,is_card=is_card)
            accepted+=int(store.event(user,raw))
        except (KeyError, ValueError, TypeError, OverflowError) as exc:
            rejected.append({'index':index,'error':str(exc)})
    return {'accepted':accepted,'rejected':rejected}


def potential_duplicates(ledger: Ledger, window_seconds=900):
    """Suggestions only; never alter or merge the ledger."""
    out=[]
    for i,e in enumerate(ledger.events):
        for other in ledger.events[i+1:]:
            if (e.account_id==other.account_id and e.direction==other.direction
                and e.amount_paise==other.amount_paise and e.ref is None and other.ref is None
                and abs((e.ts-other.ts).total_seconds())<=window_seconds
                and {r.source for r in e.evidence}!={r.source for r in other.evidence}):
                out.append({'first':e.id,'second':other.id,'reason':'same amount/account/time; reference unavailable'})
    return out


def balance_discrepancies(ledger: Ledger, as_of: datetime):
    """Report evidence gaps: accounts without snapshots and stale snapshots."""
    return {'missing_liquid_snapshots':ledger.accounts_without_snapshot(as_of),
            'unlinked_refund_event_ids':[e.id for e in ledger.unlinked_refunds(as_of)],
            'pending_salary_event_ids':[e.id for e in ledger.pending_salary_candidates(as_of)]}
