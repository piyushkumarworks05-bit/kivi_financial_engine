"""Synthetic AA-like payloads, strictly isolated from real financial accounts."""
from __future__ import annotations
from datetime import datetime,timedelta
from .ledger import Account,AcctType,Commitment,RawEvent,Kind

def load_synthetic_profile(store,user,now):
    if not user.startswith('demo:'):raise ValueError('Synthetic profile requires demo: namespace')
    store.account(user,Account('demo_bank',AcctType.SAVINGS,'DEMO Bank'))
    store.account(user,Account('demo_card',AcctType.CARD,'DEMO Credit Card'))
    store.snapshot(user,'demo_bank',now,4200000,'demo_aa')
    store.snapshot(user,'demo_card',now,320000,'demo_aa')
    store.setting(user,'payday_day',5)
    store.setting(user,'accounts_complete',True)
    store.setting(user,'next_payday',(now.date()+timedelta(days=15)).isoformat())
    for i,(amount,merchant,category) in enumerate([(32000,'Swiggy','food'),(21000,'Zomato','food'),(9000,'Rapido','transport')]):
        store.event(user,RawEvent('demo_aa',f'demo_tx_{i}','demo_bank','debit',amount,now-timedelta(days=i+1),Kind.SPEND,merchant,category))
    store.commitment(user,Commitment('demo_emi','DEMO EMI',250000,now.date()+timedelta(days=7)))
    return {'demo':True,'user':user,'note':'All records synthetic; never combine with real user balances.'}
