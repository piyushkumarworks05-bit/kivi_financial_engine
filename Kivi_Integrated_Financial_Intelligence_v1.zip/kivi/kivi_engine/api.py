"""Local development JSON HTTP API. Not internet-safe: NO authentication or TLS.

Run only on loopback; a production gateway must provide real authentication and authorization.
"""
from __future__ import annotations
from http.server import BaseHTTPRequestHandler,ThreadingHTTPServer
from urllib.parse import urlparse,parse_qs
from datetime import datetime,date
from pathlib import Path
import json
from .storage import Store
from .service import dashboard
from .ledger import Account,AcctType,Commitment,RawEvent,Kind
from .sms import assess_sms
from .reconciliation import ingest_aa
from .demo_aa import load_synthetic_profile
from .intelligence import habit_reduction,goal_forecast

def serve(path='kivi.sqlite3',host='127.0.0.1',port=8765):
    class Handler(BaseHTTPRequestHandler):
        def _reply(self,status,obj):
            data=json.dumps(obj,default=str).encode()
            self.send_response(status);self.send_header('Content-Type','application/json')
            self.send_header('Content-Length',str(len(data)));self.end_headers();self.wfile.write(data)
        def _handle(self):
            parsed=urlparse(self.path)
            params=parse_qs(parsed.query)
            user=params.get('user',['demo'])[0]
            if not user or len(user)>128:raise ValueError('invalid user')
            payload={}
            if self.command=='POST':
                length=int(self.headers.get('Content-Length','0'))
                if length>1000000:raise ValueError('payload too large')
                payload=json.loads(self.rfile.read(length) or b'{}')
            store=Store(path)
            try:
                route=parsed.path
                if self.command=='GET' and route=='/':
                    page=Path(__file__).resolve().parent.parent/'web'/'index.html'
                    data=page.read_bytes();self.send_response(200);self.send_header('Content-Type','text/html; charset=utf-8');self.send_header('Content-Length',str(len(data)));self.end_headers();self.wfile.write(data);return
                if self.command=='GET' and route=='/health':return self._reply(200,{'status':'ok','mode':'local-development'})
                if self.command=='GET' and route=='/dashboard':
                    ts=datetime.fromisoformat(params['as_of'][0]) if 'as_of' in params else datetime.now().astimezone()
                    return self._reply(200,dashboard(store,user,ts))
                if self.command=='POST' and route=='/account':
                    store.account(user,Account(payload['id'],AcctType(payload['type']),payload.get('name','')))
                elif self.command=='POST' and route=='/snapshot':
                    store.snapshot(user,payload['account_id'],datetime.fromisoformat(payload['ts']),int(payload['amount_paise']),payload.get('source','aa'))
                elif self.command=='POST' and route=='/transaction':
                    data=dict(payload);data['ts']=datetime.fromisoformat(data['ts']);data['kind']=Kind(data['kind']);store.event(user,RawEvent(**data))
                elif self.command=='POST' and route in ('/sms','/sms/batch'):
                    entries=payload.get('messages',[]) if route=='/sms/batch' else [payload]
                    if not isinstance(entries,list) or len(entries)>500:raise ValueError('messages must be a list of at most 500')
                    outcomes=[]
                    for msg in entries:
                        assessment=assess_sms(msg['text'],msg['account_id'],datetime.fromisoformat(msg['received_ts']),
                            msg.get('source_id'),msg.get('sender'),msg.get('expected_account_tail'))
                        outcome={'status':assessment.status,'reason':assessment.reason,
                                 'confidence':assessment.confidence,'account_tail':assessment.account_tail,
                                 'parser_version':assessment.parser_version}
                        if assessment.raw_event:
                            store.event(user,assessment.raw_event)
                            outcome['amount_paise']=assessment.raw_event.amount_paise
                            outcome['direction']=assessment.raw_event.direction
                            outcome['reference']=assessment.raw_event.ref
                        outcomes.append(outcome)
                    return self._reply(200,{'results':outcomes,'accepted':sum(o['status']=='accepted' for o in outcomes),
                                             'review':sum(o['status']=='review' for o in outcomes)})
                elif self.command=='POST' and route=='/aa':
                    return self._reply(200,ingest_aa(store,user,payload['account_id'],payload['transactions'],is_card=payload.get('is_card',False)))
                elif self.command=='POST' and route=='/commitment':
                    store.commitment(user,Commitment(payload['id'],payload['name'],int(payload['amount_paise']),date.fromisoformat(payload['due'])))
                elif self.command=='POST' and route=='/goal':
                    store.goal(user,payload['id'],payload['name'],int(payload['amount_paise']),payload.get('approved',True))
                elif self.command=='POST' and route=='/target':
                    store.target(user,payload['id'],payload['merchant_or_category'],int(payload['ceiling_paise']),date.fromisoformat(payload['period_start']),date.fromisoformat(payload['period_end']))
                elif self.command=='POST' and route=='/demo/load':
                    if not user.startswith('demo:'):raise ValueError('demo user namespace required')
                    return self._reply(200,load_synthetic_profile(store,user,datetime.now().astimezone()))
                elif self.command=='POST' and route=='/habit/projection':
                    return self._reply(200,habit_reduction(int(payload['monthly_spend_paise']),int(payload['reduction_percent'])))
                elif self.command=='POST' and route=='/goal/forecast':
                    return self._reply(200,goal_forecast(int(payload['goal_paise']),int(payload.get('already_saved_paise',0)),int(payload['monthly_contribution_paise'])))
                elif self.command=='POST' and route=='/onboarding':
                    from .ledger import Account,AcctType
                    ts=datetime.fromisoformat(payload['as_of']) if 'as_of' in payload else datetime.now().astimezone()
                    if ts.tzinfo is None:raise ValueError('timezone required')
                    amount=int(payload['available_balance_paise']);salary=int(payload['monthly_salary_paise']);day=int(payload['payday_day'])
                    if amount<0 or salary<0 or not 1<=day<=31:raise ValueError('invalid onboarding')
                    account_id=payload.get('account_id','onboarding_bank')
                    store.account(user,Account(account_id,AcctType.SAVINGS,'User-reported balance'))
                    store.snapshot(user,account_id,ts,amount,'user_reported')
                    store.setting(user,'monthly_salary_paise',salary)
                    store.setting(user,'payday_day',day)
                    store.setting(user,'accounts_complete',False)
                elif self.command=='POST' and route=='/setting':
                    if payload['key'] not in {'next_payday','payday_day','emergency_reserve_paise','accounts_complete','monthly_salary_paise'}:raise ValueError('unsupported setting')
                    store.setting(user,payload['key'],payload['value'])
                elif self.command=='POST' and route=='/correct':
                    store.correct(user,payload['source'],payload['source_id'],Kind(payload['kind']),payload.get('note',''))
                else:return self._reply(404,{'error':'unknown endpoint'})
                return self._reply(200,{'ok':True})
            finally:store.close()
        def do_GET(self):
            try:self._handle()
            except (ValueError,KeyError,TypeError) as e:self._reply(400,{'error':str(e)})
        def do_POST(self):
            try:self._handle()
            except (ValueError,KeyError,TypeError) as e:self._reply(400,{'error':str(e)})
    print(f'Kivi local API: http://{host}:{port} (development only)')
    ThreadingHTTPServer((host,port),Handler).serve_forever()

if __name__=='__main__':serve()
