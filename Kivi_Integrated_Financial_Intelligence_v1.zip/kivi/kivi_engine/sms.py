"""Evidence-first Indian financial SMS intelligence for Kivi.

Inspired by the user-supplied Expense_tracker parser's transaction-clause filtering
and Umber's explicit rejection, account-tail, reference, and balance extraction.
This is original Python implementation; not a claim of bank-wide coverage.
"""
from __future__ import annotations
from dataclasses import dataclass
from datetime import datetime
from decimal import Decimal, InvalidOperation
import hashlib
import re
from .ledger import RawEvent, Kind
from .money import rupees

VERSION = 3
CUR = r'(?:₹|INR\b|Rs\.?\s*)'
AMOUNT = re.compile(r'(?<!\w)(?:₹\s*|INR\s*|Rs\.?\s*)(\d[\d,]*(?:\.\d{1,2})?)', re.I)
SUFFIX = re.compile(r'(?<![xX*\d])(\d[\d,]*(?:\.\d{1,2})?)\s*(?:INR|rupees)\b', re.I)
BARE = re.compile(r'\b(?:debited|credited|spent|paid|withdrawn)\s+(?:by|with|for|of)?\s*(\d[\d,]*(?:\.\d{1,2})?)\b',re.I)
BAL = re.compile(r'\b(?:avl|available|closing|current|ledger|remaining)\s*(?:bal|balance)\b|\bbal(?:ance)?\s*(?:is|:)',re.I)
DEBIT = re.compile(r'\b(?:debited|debit(?:ed)?\s+by|spent|paid|withdrawn|deducted|sent|purchased|charged|transferred\s+to)\b',re.I)
CREDIT = re.compile(r'\b(?:credited|received|deposited|refund(?:ed)?|reversed|cashback)\b',re.I)
CARD = re.compile(r'\b(?:credit|debit)\s+card\b|\bcredit\s+limit\b',re.I)
FAILED = re.compile(r'\b(?:failed|declined|unsuccessful|rejected|not\s+(?:debited|credited|deducted)|could\s+not\s+be\s+processed|transaction\s+cancelled)\b',re.I)
FUTURE = re.compile(r'\b(?:will\s+be\s+(?:debited|credited|charged|deducted)|scheduled\s+(?:payment|debit)|due\s+on|payment\s+request|collect\s+request|has\s+requested|approve\s+payment)\b',re.I)
OTP = re.compile(r'\b(?:otp|one[ -]?time\s+password|verification\s+code|cvv)\b',re.I)
PROMO = re.compile(r'\b(?:pre[ -]?approved|apply\s+now|limited\s+offer|you\s+have\s+won|congratulations|refer\s+and\s+earn|upgrade\s+your|offer\s+ends)\b',re.I)
INFO = re.compile(r'\b(?:mini\s+statement|e-statement|statement\s+is\s+ready|statement\s+has\s+been\s+generated)\b',re.I)
REF = re.compile(r'\b(?:UPI\s*(?:ref(?:erence)?|txn|transaction)?|UTR|RRN|retrieval\s+ref(?:erence)?|Ref(?:erence)?(?:\s+No)?|Txn\s*ID|Transaction\s*ID)\s*(?:no\.?|id|#)?\s*[:.#-]?\s*(\d{9,18})\b',re.I)
VPA = re.compile(r'(?<![\w.])([\w.\-]{2,64}@[\w.\-]{2,32})\b')
ACCOUNT = re.compile(r'\b(?:a/c|acct|account|card)\s*(?:no\.?|ending\s*(?:with)?|number)?\s*[:#-]?\s*[xX*]{1,12}\s*(\d{3,6})\b',re.I)
DATE = re.compile(r'\b(\d{1,2})[-/](\d{1,2})[-/](\d{2,4})\b')
MERCHANT = re.compile(r'\b(?:at|to|towards|merchant)\s+([A-Za-z][\w &.\-]{1,45}?)(?=\s+(?:on|via|ref|upi|rrn|avl|available|bal|from|a/c|account)\b|[.;]|$)',re.I)

@dataclass(frozen=True)
class SMSAssessment:
    status: str  # accepted | review | ignored
    reason: str
    raw_event: RawEvent | None = None
    account_tail: str | None = None
    confidence: str = 'none'  # high | medium | low | none
    balance_paise: int | None = None  # evidence only; NEVER automatically applied
    parser_version: int = VERSION


def _amounts(segment):
    matches=[]
    for regex in (AMOUNT,SUFFIX,BARE):
        for m in regex.finditer(segment):
            try:
                value=rupees(Decimal(m.group(1).replace(',','')))
            except (InvalidOperation,ValueError):
                continue
            if value>0: matches.append((m.start(),m.end(),value))
    return sorted(matches)


def _separate_balance(text):
    """Balance fragments are never candidate transaction amounts."""
    pieces=re.split(r'(?<=[.;])\s+|\s+(?=\b(?:Avl|Available|Closing|Current|Remaining)\s+Bal)',text,flags=re.I)
    txn=[];balances=[]
    for p in pieces:
        if BAL.search(p) and not (DEBIT.search(CARD.sub('',p)) or CREDIT.search(CARD.sub('',p))):
            balances.extend(_amounts(p))
        else:txn.append(p)
    return ' '.join(txn), balances[-1][2] if balances else None


def assess_sms(text:str, account_id:str, received_ts:datetime, source_id:str|None=None,
               sender:str|None=None, expected_account_tail:str|None=None)->SMSAssessment:
    if received_ts.tzinfo is None:raise ValueError('SMS receipt time must be timezone-aware')
    if not account_id:raise ValueError('account_id is required')
    if not isinstance(text,str) or not text.strip():return SMSAssessment('ignored','empty')
    body=' '.join(text.split())
    if len(body)>5000:return SMSAssessment('review','message_too_long')
    if sender and re.fullmatch(r'\+?\d{10,13}',sender.replace(' ','')):
        return SMSAssessment('review','unverified_numeric_sender')
    if OTP.search(body):return SMSAssessment('ignored','otp_or_security_message')
    if FAILED.search(body):return SMSAssessment('ignored','failed_transaction')
    if FUTURE.search(body):return SMSAssessment('ignored','pending_or_future_transaction')
    if PROMO.search(body):return SMSAssessment('ignored','promotional_message')
    if INFO.search(body):return SMSAssessment('ignored','informational_message')
    clean=CARD.sub('',body)
    d=bool(DEBIT.search(clean));c=bool(CREDIT.search(clean))
    if d==c:return SMSAssessment('review' if d else 'ignored','ambiguous_direction' if d else 'no_transaction_verb')
    account=ACCOUNT.search(body)
    tail=account.group(1) if account else None
    if expected_account_tail and tail and tail!=expected_account_tail:
        return SMSAssessment('review','account_mismatch',account_tail=tail)
    transaction,bal=_separate_balance(body)
    amounts=_amounts(transaction)
    if not amounts:return SMSAssessment('review','missing_transaction_amount',account_tail=tail,balance_paise=bal)
    # Distinct transaction amounts in one SMS require review; avoid guessing between fees/amounts.
    distinct={a[2] for a in amounts}
    if len(distinct)>1:return SMSAssessment('review','multiple_transaction_amounts',account_tail=tail,balance_paise=bal)
    value=amounts[0][2]
    ref=REF.search(body)
    vpa=VPA.search(body)
    merchant_match=MERCHANT.search(transaction)
    merchant=vpa.group(1).split('@')[0] if vpa else (merchant_match.group(1).strip() if merchant_match else None)
    kind=Kind.SPEND if d else Kind.INCOME
    if c and re.search(r'\b(?:refund|reversal|reversed)\b',body,re.I):kind=Kind.REFUND
    if d and re.search(r'\bcredit\s+card\b',body,re.I):kind=Kind.CARD_PURCHASE
    if d and re.search(r'\b(?:credit\s+card\s+bill|card\s+payment|cc\s+bill)\b',body,re.I):kind=Kind.CARD_PAYMENT
    # SMS receipt time is a proxy, never asserted as exact purchase time.
    ts=received_ts
    match=DATE.search(body)
    if match:
        day,month,year=map(int,match.groups());year=year+2000 if year<100 else year
        try:ts=received_ts.replace(year=year,month=month,day=day)
        except ValueError:pass
    sid=source_id or hashlib.sha256(f'{account_id}|{sender or ""}|{body}|{received_ts.isoformat()}'.encode()).hexdigest()
    raw=RawEvent(source='sms',source_id=sid,account_id=account_id,
        direction='debit' if d else 'credit',amount_paise=value,ts=ts,kind=kind,
        merchant=merchant,ref=ref.group(1) if ref else None,
        salary_candidate=bool(c and re.search(r'\bsalary\b',body,re.I)))
    confidence='high' if ref and tail else 'medium' if ref or tail else 'low'
    return SMSAssessment('accepted','parsed',raw,tail,confidence,bal)


def parse_sms(text:str,account_id:str,received_ts:datetime,source_id:str|None=None):
    """Compatibility adapter for existing Kivi Store/API. For detailed review use assess_sms."""
    return assess_sms(text,account_id,received_ts,source_id).raw_event
