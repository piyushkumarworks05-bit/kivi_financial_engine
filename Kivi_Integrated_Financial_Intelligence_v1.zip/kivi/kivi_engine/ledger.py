"""In-memory ledger: idempotent ingestion, cross-source reconciliation, audit trail.

Raw evidence is never discarded. One real-world transaction == one EconomicEvent, however many
sources (AA / SMS / manual) reported it. Corrections are recorded in an audit list.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from datetime import date, datetime, timedelta
from enum import Enum

from .config import Config, DEFAULT, IST


class Kind(str, Enum):
    SALARY = "salary"
    INCOME = "income"                      # any other credit (a credit is NOT automatically salary)
    SPEND = "spend"
    OBLIGATION_PAYMENT = "obligation_payment"
    TRANSFER_OWN = "transfer_own"          # between the user's own accounts: not spend, not income
    REFUND = "refund"
    CARD_PURCHASE = "card_purchase"        # consumption, on a card account
    CARD_PAYMENT = "card_payment"          # settles the card liability: NOT new consumption


class AcctType(str, Enum):
    SAVINGS = "savings"   # liquid
    CARD = "card"         # credit card: balance snapshot = outstanding liability
    GOAL = "goal"         # own account holding protected money (not liquid for spending)


SOURCE_RANK = {"aa": 3, "manual": 2, "sms": 1}
TRANSFER_KINDS = {Kind.TRANSFER_OWN, Kind.CARD_PAYMENT}


def local_date(ts: datetime) -> date:
    return ts.astimezone(IST).date()


@dataclass(frozen=True)
class Account:
    id: str
    type: AcctType
    name: str = ""


@dataclass(frozen=True)
class Snapshot:
    account_id: str
    ts: datetime
    amount_paise: int   # balance for SAVINGS; outstanding liability for CARD
    source: str


@dataclass(frozen=True)
class Commitment:
    id: str
    name: str
    amount_paise: int
    due: date


@dataclass(frozen=True)
class RawEvent:
    source: str                 # "aa" | "sms" | "manual"
    source_id: str              # idempotency key within the source
    account_id: str
    direction: str              # "debit" | "credit"
    amount_paise: int
    ts: datetime                # timezone-aware event time
    kind: Kind
    merchant: str | None = None
    category: str | None = None
    ref: str | None = None      # e.g. UPI reference
    counterparty_account_id: str | None = None
    linked_to: int | None = None      # refund -> original economic event id
    commitment_id: str | None = None
    goal_id: str | None = None
    salary_candidate: bool = False    # looks like salary, NOT yet confirmed by the user


@dataclass
class EconomicEvent:
    id: int
    account_id: str
    direction: str
    amount_paise: int
    ts: datetime
    kind: Kind
    merchant: str | None
    category: str | None
    ref: str | None
    counterparty_account_id: str | None
    linked_to: int | None
    commitment_id: str | None
    goal_id: str | None
    salary_candidate: bool
    evidence: list = field(default_factory=list)   # every RawEvent that reported this event
    pair_with: int | None = None                   # other leg of a transfer / card payment
    user_corrected: bool = False


@dataclass(frozen=True)
class IngestResult:
    status: str      # "new" | "replay" | "merged"
    event_id: int


class Ledger:
    def __init__(self, cfg: Config = DEFAULT):
        self.cfg = cfg
        self.accounts: dict[str, Account] = {}
        self.snapshots: list[Snapshot] = []
        self.events: list[EconomicEvent] = []
        self.audit: list[dict] = []
        self._seen: dict[tuple, int] = {}

    # ---- setup -------------------------------------------------------------------------
    def add_account(self, acct: Account) -> None:
        self.accounts[acct.id] = acct

    def add_snapshot(self, account_id: str, ts: datetime, amount_paise: int, source: str = "aa") -> None:
        if ts.tzinfo is None:
            raise ValueError("snapshot ts must be timezone-aware")
        self.snapshots.append(Snapshot(account_id, ts, amount_paise, source))

    # ---- ingestion ---------------------------------------------------------------------
    def ingest(self, raw: RawEvent) -> IngestResult:
        if raw.amount_paise <= 0:
            raise ValueError("amount must be positive paise")
        if raw.ts.tzinfo is None:
            raise ValueError("event ts must be timezone-aware")
        if raw.direction not in ("debit", "credit"):
            raise ValueError("direction must be debit|credit")
        key = (raw.source, raw.source_id)
        if key in self._seen:                       # idempotent replay
            return IngestResult("replay", self._seen[key])

        for e in reversed(self.events):             # same real event reported by another source?
            if self._same_event(e, raw):
                self._merge(e, raw)
                self._seen[key] = e.id
                return IngestResult("merged", e.id)

        e = EconomicEvent(
            id=len(self.events) + 1, account_id=raw.account_id, direction=raw.direction,
            amount_paise=raw.amount_paise, ts=raw.ts, kind=raw.kind, merchant=raw.merchant,
            category=raw.category, ref=raw.ref, counterparty_account_id=raw.counterparty_account_id,
            linked_to=raw.linked_to, commitment_id=raw.commitment_id, goal_id=raw.goal_id,
            salary_candidate=raw.salary_candidate, evidence=[raw])
        self.events.append(e)
        self._seen[key] = e.id
        if e.kind in TRANSFER_KINDS:
            self._pair_legs(e)
        return IngestResult("new", e.id)

    def _same_event(self, e: EconomicEvent, raw: RawEvent) -> bool:
        if (e.account_id, e.direction, e.amount_paise) != (raw.account_id, raw.direction, raw.amount_paise):
            return False
        if raw.source in {ev.source for ev in e.evidence}:
            return False        # two events from the SAME source are two real events (two ₹50 chais)
        if e.ref and raw.ref:
            return e.ref == raw.ref and abs(e.ts - raw.ts) <= timedelta(days=1)
        # Amount and time alone are not sufficient to merge two real purchases.
        # Cross-source merges require the same nonempty transaction reference.
        return False

    def _merge(self, e: EconomicEvent, raw: RawEvent) -> None:
        higher = SOURCE_RANK.get(raw.source, 0) > SOURCE_RANK.get(e.evidence[0].source, 0)
        e.evidence.append(raw)
        for attr in ("merchant", "category", "ref", "counterparty_account_id", "commitment_id", "goal_id"):
            if getattr(e, attr) is None and getattr(raw, attr) is not None:
                setattr(e, attr, getattr(raw, attr))
        if higher:
            e.ts = raw.ts
            if not e.user_corrected:
                e.kind = raw.kind
            e.salary_candidate = e.salary_candidate and raw.salary_candidate

    def _pair_legs(self, e: EconomicEvent) -> None:
        window = timedelta(minutes=self.cfg.dedupe_window_minutes)
        for o in reversed(self.events[:-1]):
            if (o.pair_with is None and o.kind in TRANSFER_KINDS and o.direction != e.direction
                    and o.amount_paise == e.amount_paise and abs(o.ts - e.ts) <= window
                    and o.account_id != e.account_id
                    and (o.counterparty_account_id == e.account_id
                         or e.counterparty_account_id == o.account_id)):
                o.pair_with, e.pair_with = e.id, o.id
                return

    # ---- user corrections (never rewrite history silently) ------------------------------
    def reclassify(self, event_id: int, kind: Kind, note: str = "", by: str = "user") -> None:
        e = self.events[event_id - 1]
        self.audit.append({"event_id": event_id, "field": "kind", "old": e.kind.value,
                           "new": kind.value, "by": by, "note": note})
        e.kind = kind
        e.user_corrected = True
        if kind == Kind.SALARY:
            e.salary_candidate = False

    def confirm_salary(self, event_id: int) -> None:
        self.reclassify(event_id, Kind.SALARY, note="user confirmed this credit is salary")

    def link_refund(self, refund_event_id: int, original_event_id: int) -> None:
        e = self.events[refund_event_id - 1]
        self.audit.append({"event_id": refund_event_id, "field": "linked_to", "old": e.linked_to,
                           "new": original_event_id, "by": "user", "note": "refund linked"})
        e.linked_to = original_event_id

    # ---- queries (every one is bounded by as_of so replays are deterministic) --------------
    def events_until(self, as_of: datetime) -> list[EconomicEvent]:
        return [e for e in self.events if e.ts <= as_of]

    def confirmed_salary_dates(self, as_of: datetime) -> list[date]:
        return [local_date(e.ts) for e in self.events_until(as_of)
                if e.kind == Kind.SALARY and e.direction == "credit"]

    def pending_salary_candidates(self, as_of: datetime) -> list[EconomicEvent]:
        return [e for e in self.events_until(as_of)
                if e.kind == Kind.INCOME and e.salary_candidate and e.direction == "credit"]

    def _latest_snapshot(self, account_id: str, as_of: datetime) -> Snapshot | None:
        snaps = [s for s in self.snapshots if s.account_id == account_id and s.ts <= as_of]
        return max(snaps, key=lambda s: s.ts) if snaps else None

    def liquid_accounts(self) -> list[Account]:
        return [a for a in self.accounts.values() if a.type == AcctType.SAVINGS]

    def liquid_balance(self, as_of: datetime) -> tuple[int | None, datetime | None]:
        """Sum of (latest snapshot + later events) over liquid accounts, and the oldest snapshot
        timestamp used. Events at/before the snapshot are ALREADY in the snapshot: never re-applied."""
        total, oldest, found = 0, None, False
        for acct in self.liquid_accounts():
            snap = self._latest_snapshot(acct.id, as_of)
            if snap is None:
                continue
            found = True
            bal = snap.amount_paise
            for e in self.events_until(as_of):
                if e.account_id == acct.id and e.ts > snap.ts:
                    bal += e.amount_paise if e.direction == "credit" else -e.amount_paise
            total += bal
            oldest = snap.ts if oldest is None else min(oldest, snap.ts)
        return (total if found else None), oldest

    def accounts_without_snapshot(self, as_of: datetime) -> list[str]:
        return [a.id for a in self.liquid_accounts() if self._latest_snapshot(a.id, as_of) is None]

    def card_outstanding(self, as_of: datetime) -> int:
        """Money owed on credit cards. Purchases add; payments subtract (once, never as spend)."""
        total = 0
        for acct in self.accounts.values():
            if acct.type != AcctType.CARD:
                continue
            snap = self._latest_snapshot(acct.id, as_of)
            base = snap.amount_paise if snap else 0
            since = snap.ts if snap else None
            out = base
            for e in self.events_until(as_of):
                if since is not None and e.ts <= since:
                    continue
                if e.account_id == acct.id:                       # card-side leg
                    out += e.amount_paise if e.direction == "debit" else -e.amount_paise
                elif (e.kind == Kind.CARD_PAYMENT and e.counterparty_account_id == acct.id
                      and e.pair_with is None):                    # liquid-side leg, no card-side leg seen
                    out -= e.amount_paise
            total += max(out, 0)
        return total

    def net_spend_on(self, day: date, as_of: datetime) -> int:
        """Consumption on a local date: spends and card purchases, minus LINKED refunds."""
        total = 0
        for e in self.events_until(as_of):
            if local_date(e.ts) != day:
                continue
            if e.kind in (Kind.SPEND, Kind.CARD_PURCHASE) and e.direction == "debit":
                total += e.amount_paise
            elif e.kind == Kind.REFUND and e.direction == "credit" and e.linked_to is not None:
                total -= e.amount_paise
        return total

    def commitment_paid(self, commitment_id: str, as_of: datetime) -> int:
        return sum(e.amount_paise for e in self.events_until(as_of)
                   if e.kind == Kind.OBLIGATION_PAYMENT and e.direction == "debit"
                   and e.commitment_id == commitment_id)

    def goal_funded_since(self, goal_id: str, since: date, as_of: datetime) -> int:
        return sum(e.amount_paise for e in self.events_until(as_of)
                   if e.kind == Kind.TRANSFER_OWN and e.direction == "debit"
                   and e.goal_id == goal_id and local_date(e.ts) >= since)

    def unlinked_refunds(self, as_of: datetime) -> list[EconomicEvent]:
        return [e for e in self.events_until(as_of)
                if e.kind == Kind.REFUND and e.linked_to is None]
