"""Kivi engine: deterministic money logic. No LLM, no third-party dependencies."""
