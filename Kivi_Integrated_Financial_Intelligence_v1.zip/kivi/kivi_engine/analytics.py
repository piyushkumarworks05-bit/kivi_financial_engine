"""Evidence-based spending insights, behavioral targets, and suspected recurring payments."""
from __future__ import annotations
from collections import defaultdict
from datetime import date, timedelta
from .ledger import Ledger,Kind,local_date


def spending_summary(ledger:Ledger, start:date,end:date,as_of):
    merchants=defaultdict(int);categories=defaultdict(int);income=0;spend=0
    for e in ledger.events_until(as_of):
        if not(start<=local_date(e.ts)<=end):continue
        if e.direction=='debit' and e.kind in (Kind.SPEND,Kind.CARD_PURCHASE):
            merchants[e.merchant or 'Unidentified']+=e.amount_paise
            categories[e.category or 'Uncategorized']+=e.amount_paise
            spend+=e.amount_paise
        elif e.direction=='credit' and e.kind in (Kind.SALARY,Kind.INCOME): income+=e.amount_paise
    return {'income_paise':income,'spend_paise':spend,'by_merchant_paise':dict(merchants),'by_category_paise':dict(categories)}


def spending_targets(ledger:Ledger,targets:list[dict],as_of):
    result=[]
    for t in targets:
        start=date.fromisoformat(t['period_start']);end=date.fromisoformat(t['period_end']);key=t['merchant_or_category'].casefold()
        used=sum(e.amount_paise for e in ledger.events_until(as_of)
                 if start<=local_date(e.ts)<=end and e.direction=='debit' and e.kind in (Kind.SPEND,Kind.CARD_PURCHASE)
                 and (key==(e.merchant or '').casefold() or key==(e.category or '').casefold()))
        result.append({'id':t['id'],'target_paise':t['ceiling_paise'],'spent_paise':used,
                       'remaining_paise':max(0,t['ceiling_paise']-used),'exceeded':used>t['ceiling_paise']})
    return result


def suspected_recurring(ledger:Ledger,as_of,minimum_occurrences=2):
    """A recurrence is a suspicion, not proof that a purchase was forgotten."""
    by_merchant=defaultdict(list)
    for e in ledger.events_until(as_of):
        if e.direction=='debit' and e.kind in (Kind.SPEND,Kind.CARD_PURCHASE) and e.merchant:
            by_merchant[e.merchant.casefold()].append(e)
    findings=[]
    for merchant,events in by_merchant.items():
        events.sort(key=lambda e:e.ts)
        if len(events)<minimum_occurrences:continue
        for a,b in zip(events,events[1:]):
            gap=(local_date(b.ts)-local_date(a.ts)).days
            if 25<=gap<=35:
                findings.append({'merchant':merchant,'amount_paise':b.amount_paise,'last_event_id':b.id,
                                 'status':'suspected_recurring','amount_changed':a.amount_paise!=b.amount_paise})
                break
    return findings
