"""Evidence-based insights. Categories come only from KNOWN merchants; unknown stays unknown."""
from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timedelta

from .config import Config, DEFAULT, IST
from .ledger import Kind, Ledger, local_date

# Merchant alias table (extend freely). Anything not matched stays category=None.
KNOWN_MERCHANTS = {
    "swiggy": "food_delivery", "zomato": "food_delivery", "eatsure": "food_delivery",
    "blinkit": "quick_commerce", "zepto": "quick_commerce", "instamart": "quick_commerce",
    "netflix": "subscription", "spotify": "subscription", "hotstar": "subscription",
    "uber": "transport", "ola": "transport", "rapido": "transport",
}


def categorize_merchant(name: str | None) -> str | None:
    if not name:
        return None
    n = name.lower()
    for alias, cat in KNOWN_MERCHANTS.items():
        if alias in n:
            return cat
    return None


@dataclass(frozen=True)
class FoodPattern:
    orders: int
    total_paise: int
    late_night_orders: int
    late_night_total_paise: int
    window_days: int
    event_ids: tuple


def is_late_night(ts: datetime, cfg: Config = DEFAULT) -> bool:
    h = ts.astimezone(IST).hour
    return h >= cfg.late_night_start_hour or h < cfg.late_night_end_hour


def food_delivery_pattern(ledger: Ledger, as_of: datetime, cfg: Config = DEFAULT) -> FoodPattern | None:
    """Repeated food-delivery orders in the recent window, from KNOWN merchants only."""
    since = as_of - timedelta(days=cfg.food_pattern_window_days)
    evs = [e for e in ledger.events_until(as_of)
           if e.kind in (Kind.SPEND, Kind.CARD_PURCHASE) and e.category == "food_delivery" and e.ts > since]
    if len(evs) < cfg.food_pattern_min_orders:
        return None
    late = [e for e in evs if is_late_night(e.ts, cfg)]
    return FoodPattern(len(evs), sum(e.amount_paise for e in evs), len(late),
                       sum(e.amount_paise for e in late), cfg.food_pattern_window_days,
                       tuple(e.id for e in evs))
