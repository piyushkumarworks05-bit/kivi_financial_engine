"""Durable, user-scoped SQLite storage for financial engine state.

Single-process deployment. SQLite WAL and transactions provide durable commits; use a
managed database and authorization layer before multi-instance production deployment.
"""
from __future__ import annotations
import json
import sqlite3
from datetime import datetime, date
from dataclasses import asdict
from pathlib import Path
from .ledger import Ledger, Account, AcctType, RawEvent, Kind, Commitment
from .config import DEFAULT

SCHEMA = '''
PRAGMA foreign_keys=ON;
CREATE TABLE IF NOT EXISTS accounts (user_id TEXT NOT NULL, id TEXT NOT NULL, type TEXT NOT NULL, name TEXT NOT NULL, PRIMARY KEY(user_id,id));
CREATE TABLE IF NOT EXISTS snapshots (user_id TEXT NOT NULL, account_id TEXT NOT NULL, ts TEXT NOT NULL, amount_paise INTEGER NOT NULL, source TEXT NOT NULL, PRIMARY KEY(user_id,account_id,ts,source));
CREATE TABLE IF NOT EXISTS raw_events (user_id TEXT NOT NULL, source TEXT NOT NULL, source_id TEXT NOT NULL, payload TEXT NOT NULL, PRIMARY KEY(user_id,source,source_id));
CREATE TABLE IF NOT EXISTS corrections (id INTEGER PRIMARY KEY AUTOINCREMENT, user_id TEXT NOT NULL, source TEXT NOT NULL, source_id TEXT NOT NULL, kind TEXT NOT NULL, note TEXT NOT NULL, created_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS commitments (user_id TEXT NOT NULL, id TEXT NOT NULL, name TEXT NOT NULL, amount_paise INTEGER NOT NULL, due TEXT NOT NULL, PRIMARY KEY(user_id,id));
CREATE TABLE IF NOT EXISTS goals (user_id TEXT NOT NULL, id TEXT NOT NULL, name TEXT NOT NULL, amount_paise INTEGER NOT NULL, approved INTEGER NOT NULL, PRIMARY KEY(user_id,id));
CREATE TABLE IF NOT EXISTS targets (user_id TEXT NOT NULL, id TEXT NOT NULL, merchant_or_category TEXT NOT NULL, ceiling_paise INTEGER NOT NULL, period_start TEXT NOT NULL, period_end TEXT NOT NULL, PRIMARY KEY(user_id,id));
CREATE TABLE IF NOT EXISTS settings (user_id TEXT NOT NULL, key TEXT NOT NULL, value TEXT NOT NULL, PRIMARY KEY(user_id,key));
'''

class Store:
    def __init__(self, path: str | Path):
        self.db = sqlite3.connect(str(path), timeout=15)
        self.db.row_factory = sqlite3.Row
        self.db.execute('PRAGMA journal_mode=WAL')
        self.db.executescript(SCHEMA)

    def close(self): self.db.close()

    def account(self, user: str, account: Account):
        with self.db:
            self.db.execute('INSERT INTO accounts VALUES(?,?,?,?) ON CONFLICT(user_id,id) DO UPDATE SET type=excluded.type,name=excluded.name', (user,account.id,account.type.value,account.name))

    def snapshot(self,user: str, account_id: str, ts: datetime, amount_paise: int, source='aa'):
        if ts.tzinfo is None: raise ValueError('timestamp must have timezone')
        with self.db:
            self.db.execute('INSERT OR IGNORE INTO snapshots VALUES(?,?,?,?,?)',(user,account_id,ts.isoformat(),amount_paise,source))

    def event(self,user: str, raw: RawEvent):
        if raw.ts.tzinfo is None or raw.amount_paise <= 0: raise ValueError('invalid transaction')
        payload = asdict(raw)
        payload['ts'] = raw.ts.isoformat()
        payload['kind'] = raw.kind.value
        with self.db:
            cursor=self.db.execute('INSERT OR IGNORE INTO raw_events VALUES(?,?,?,?)',(user,raw.source,raw.source_id,json.dumps(payload)))
        return cursor.rowcount == 1

    def correct(self,user: str,source: str,source_id: str,kind: Kind,note=''):
        row=self.db.execute('SELECT 1 FROM raw_events WHERE user_id=? AND source=? AND source_id=?',(user,source,source_id)).fetchone()
        if not row: raise KeyError('transaction not found')
        with self.db:
            self.db.execute('INSERT INTO corrections(user_id,source,source_id,kind,note,created_at) VALUES(?,?,?,?,?,?)',(user,source,source_id,kind.value,note,datetime.now().astimezone().isoformat()))

    def commitment(self,user: str,c: Commitment):
        with self.db:
            self.db.execute('INSERT INTO commitments VALUES(?,?,?,?,?) ON CONFLICT(user_id,id) DO UPDATE SET name=excluded.name,amount_paise=excluded.amount_paise,due=excluded.due',(user,c.id,c.name,c.amount_paise,c.due.isoformat()))

    def goal(self,user: str,id: str,name: str,amount_paise: int,approved=True):
        with self.db:
            self.db.execute('INSERT INTO goals VALUES(?,?,?,?,?) ON CONFLICT(user_id,id) DO UPDATE SET name=excluded.name,amount_paise=excluded.amount_paise,approved=excluded.approved',(user,id,name,amount_paise,int(approved)))

    def target(self,user: str,id: str,merchant_or_category: str,ceiling_paise: int,start: date,end: date):
        if ceiling_paise < 0 or end < start: raise ValueError('invalid target')
        with self.db:
            self.db.execute('INSERT INTO targets VALUES(?,?,?,?,?,?) ON CONFLICT(user_id,id) DO UPDATE SET merchant_or_category=excluded.merchant_or_category,ceiling_paise=excluded.ceiling_paise,period_start=excluded.period_start,period_end=excluded.period_end',(user,id,merchant_or_category,ceiling_paise,start.isoformat(),end.isoformat()))

    def setting(self,user: str,key: str,value):
        with self.db:
            self.db.execute('INSERT INTO settings VALUES(?,?,?) ON CONFLICT(user_id,key) DO UPDATE SET value=excluded.value',(user,key,json.dumps(value)))

    def get_setting(self,user: str,key: str,default=None):
        row=self.db.execute('SELECT value FROM settings WHERE user_id=? AND key=?',(user,key)).fetchone()
        return json.loads(row['value']) if row else default

    def load(self,user: str):
        ledger=Ledger(DEFAULT)
        for r in self.db.execute('SELECT * FROM accounts WHERE user_id=?',(user,)):
            ledger.add_account(Account(r['id'],AcctType(r['type']),r['name']))
        for r in self.db.execute('SELECT * FROM snapshots WHERE user_id=? ORDER BY ts',(user,)):
            ledger.add_snapshot(r['account_id'],datetime.fromisoformat(r['ts']),r['amount_paise'],r['source'])
        for r in self.db.execute('SELECT payload FROM raw_events WHERE user_id=? ORDER BY json_extract(payload,"$.ts"),source,source_id',(user,)):
            d=json.loads(r['payload']);d['ts']=datetime.fromisoformat(d['ts']);d['kind']=Kind(d['kind']);ledger.ingest(RawEvent(**d))
        for r in self.db.execute('SELECT * FROM corrections WHERE user_id=? ORDER BY id',(user,)):
            event_id=ledger._seen.get((r['source'],r['source_id']))
            if event_id: ledger.reclassify(event_id,Kind(r['kind']),r['note'])
        commitments=[Commitment(r['id'],r['name'],r['amount_paise'],date.fromisoformat(r['due'])) for r in self.db.execute('SELECT * FROM commitments WHERE user_id=?',(user,))]
        from .safe2spend import GoalAllocation
        goals=[GoalAllocation(r['id'],r['name'],r['amount_paise'],bool(r['approved'])) for r in self.db.execute('SELECT * FROM goals WHERE user_id=?',(user,))]
        targets=[dict(r) for r in self.db.execute('SELECT * FROM targets WHERE user_id=?',(user,))]
        return ledger,commitments,goals,targets
