"""Money is integer paise everywhere. INR formatting happens only at display."""
import re
from decimal import Decimal, ROUND_HALF_UP


def rupees(x) -> int:
    """Convert rupees (int/str/Decimal) to integer paise. Avoid floats."""
    return int((Decimal(str(x)) * 100).quantize(Decimal("1"), rounding=ROUND_HALF_UP))


def fmt(paise: int) -> str:
    """Indian digit grouping, e.g. 1234567 paise -> ₹12,345.67 ; whole rupees drop decimals."""
    sign = "-" if paise < 0 else ""
    r, p = divmod(abs(paise), 100)
    s = str(r)
    if len(s) > 3:
        head, tail = s[:-3], s[-3:]
        head = re.sub(r"(\d)(?=(\d\d)+$)", r"\1,", head)
        s = head + "," + tail
    return f"{sign}₹{s}" + (f".{p:02d}" if p else "")


def floor_to(paise: int, step: int) -> int:
    return (paise // step) * step if step > 1 else paise
