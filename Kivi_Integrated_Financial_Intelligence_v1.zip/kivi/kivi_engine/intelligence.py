"""Kivi evidence-based higher-level intelligence. All money is integer paise.
These are deterministic insights, not claims that a user forgot a purchase.
"""
from __future__ import annotations
from collections import defaultdict
from datetime import date, timedelta
from .ledger import Kind,local_date

SPEND={Kind.SPEND,Kind.CARD_PURCHASE}
SENSITIVE={'medical','health','pharmacy','hospital','debt','loan','emi','bnpl','alcohol','cigarettes','tobacco','habits'}
GROUPS={'swiggy':'Swiggy','toing':'Swiggy','zomato':'Zomato','blinkit':'Blinkit','zepto':'Zepto','rapido':'Rapido','ownly':'Rapido'}

def group_merchant(name):
    if not name:return 'Unidentified'
    n=name.casefold()
    for needle,group in GROUPS.items():
        if needle in n:return group
    return name.strip()

def tracker(ledger,as_of):
    balances={};assets=0;debt=0;missing=[]
    for aid,account in ledger.accounts.items():
        s=[s for s in ledger.snapshots if s.account_id==aid and s.ts<=as_of]
        if not s:missing.append(aid);continue
        latest=max(s,key=lambda x:x.ts)
        balances[aid]={'name':account.name,'type':account.type.value,'balance_paise':latest.amount_paise,'source':latest.source,'as_of':latest.ts.isoformat()}
        if account.type.value=='card':debt+=latest.amount_paise
        else:assets+=latest.amount_paise
    return {'accounts':balances,'net_worth_known_paise':assets-debt,'known_assets_paise':assets,'known_card_debt_paise':debt,'missing_accounts':missing,'note':'Net worth excludes investments and debts without verified snapshots.'}

def spending(ledger,start,end,as_of,income_reference_paise=None):
    by_group=defaultdict(int);by_category=defaultdict(int);by_day=defaultdict(int);income=0;total=0
    for e in ledger.events_until(as_of):
        day=local_date(e.ts)
        if not start<=day<=end:continue
        if e.kind in SPEND and e.direction=='debit':
            by_group[group_merchant(e.merchant)]+=e.amount_paise
            by_category[e.category or 'Uncategorized']+=e.amount_paise
            by_day[day.isoformat()]+=e.amount_paise;total+=e.amount_paise
        elif e.kind in {Kind.SALARY,Kind.INCOME} and e.direction=='credit' and not e.salary_candidate:income+=e.amount_paise
    denominator=income_reference_paise if income_reference_paise is not None else income
    return {'spent_paise':total,'confirmed_income_paise':income,'merchant_groups_paise':dict(by_group),'categories_paise':dict(by_category),'daily_paise':dict(by_day),'percent_of_income':{k:round(v*100/denominator,2) for k,v in by_category.items()} if denominator>0 else {},'income_basis':'user_reported' if income_reference_paise is not None else 'confirmed_transactions'}

def obligations(commitments,ledger,as_of,until):
    items=[]
    for c in commitments:
        unpaid=max(0,c.amount_paise-ledger.commitment_paid(c.id,as_of))
        if unpaid and c.due<until:
            items.append({'id':c.id,'name':c.name,'due':c.due.isoformat(),'unpaid_paise':unpaid})
    return {'items':items,'total_unpaid_paise':sum(i['unpaid_paise'] for i in items)}

def goal_forecast(goal_paise,already_saved_paise,monthly_contribution_paise):
    if min(goal_paise,already_saved_paise,monthly_contribution_paise)<0:raise ValueError('negative money')
    remaining=max(0,goal_paise-already_saved_paise)
    return {'remaining_paise':remaining,'estimated_months':(remaining+monthly_contribution_paise-1)//monthly_contribution_paise if monthly_contribution_paise else (0 if remaining==0 else None),'guaranteed':False}

def habit_reduction(monthly_spend_paise,percent):
    if monthly_spend_paise<0 or not 0<=percent<=100:raise ValueError('invalid reduction')
    saved=monthly_spend_paise*percent//100
    return {'potential_monthly_savings_paise':saved,'potential_yearly_savings_paise':saved*12,'realized_savings_paise':0,'private':True,'projection_only':True}

def ghost_candidates(ledger,as_of):
    by_name=defaultdict(list)
    for e in ledger.events_until(as_of):
        if e.kind in SPEND and e.direction=='debit' and e.merchant and (e.category or '').casefold() not in SENSITIVE:
            by_name[group_merchant(e.merchant)].append(e)
    out=[]
    for name,items in by_name.items():
        items.sort(key=lambda e:e.ts)
        for a,b in zip(items,items[1:]):
            gap=(local_date(b.ts)-local_date(a.ts)).days
            if 25<=gap<=35:
                out.append({'merchant':name,'event_id':b.id,'status':'suspected','reason':'possible_monthly_recurring','amount_changed':a.amount_paise!=b.amount_paise,'question':'Still using this?'})
                break
    return out

def roast_facts(ledger,start,end,as_of):
    data=spending(ledger,start,end,as_of)
    safe={k:v for k,v in data['merchant_groups_paise'].items() if not any(s in k.casefold() for s in SENSITIVE)}
    if not safe:return {'eligible':False,'reason':'no_safe_verified_spending'}
    merchant=max(safe,key=safe.get)
    return {'eligible':True,'archetype':'The Repeat Customer','merchant':merchant,'line':f'{merchant} has had more screen time than your kitchen.','hide_amounts_by_default':True,'sensitive_excluded':True,'source':'reconciled_spending'}

def target_progress(ledger,targets,as_of):
    out=[]
    for t in targets:
        start=date.fromisoformat(t['period_start']);end=date.fromisoformat(t['period_end']);key=t['merchant_or_category'].casefold()
        used=sum(e.amount_paise for e in ledger.events_until(as_of) if start<=local_date(e.ts)<=end and e.kind in SPEND and e.direction=='debit' and (key==group_merchant(e.merchant).casefold() or key==(e.category or '').casefold()))
        out.append({'id':t['id'],'spent_paise':used,'ceiling_paise':t['ceiling_paise'],'exceeded':used>t['ceiling_paise'],'reserved_money_paise':0})
    return out
