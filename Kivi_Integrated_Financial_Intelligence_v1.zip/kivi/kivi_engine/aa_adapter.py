"""Map provider payloads to RawEvent.

IMPORTANT: the AA field names below approximate the ReBIT deposit "Transaction" shape
(txnId, type, mode, amount, currentBalance, transactionTimestamp, valueDate, narration, reference).
Verify against the real Setu / Finvu sandbox payloads before relying on it; only this file
should need to change. The SMS regex is a demo for ONE common bank format, not a general parser.
"""
from __future__ import annotations

import hashlib
import re
from datetime import datetime
from decimal import Decimal

from .insights import categorize_merchant
from .ledger import Kind, RawEvent
from .money import rupees


def parse_merchant(narration: str) -> str | None:
    """UPI/<ref>/<merchant>/<vpa>  ->  merchant. Never infers WHAT was bought."""
    parts = narration.split("/")
    if len(parts) >= 3 and parts[0].upper() == "UPI":
        return parts[2].strip().title() or None
    return None


def from_aa_txn(txn: dict, account_id: str, commitment_resolver=None, is_card: bool = False) -> RawEvent:
    narr = txn.get("narration", "")
    up = narr.upper()
    ts = datetime.fromisoformat(txn["transactionTimestamp"])
    direction = "credit" if txn["type"].upper() == "CREDIT" else "debit"
    amount = rupees(Decimal(str(txn["amount"])))
    base = dict(source="aa", source_id=str(txn["txnId"]), account_id=account_id, direction=direction,
                amount_paise=amount, ts=ts, ref=txn.get("reference"))
    m = re.search(r"CARDPAY/([A-Z0-9]+)", up)
    if m:
        return RawEvent(kind=Kind.CARD_PAYMENT, counterparty_account_id=m.group(1), **base)
    m = re.search(r"SELF-TRF-([A-Z0-9]+)", up)
    if m and direction == "debit":
        return RawEvent(kind=Kind.TRANSFER_OWN, goal_id=m.group(1).lower(),
                        counterparty_account_id=f"GOAL:{m.group(1)}", **base)
    if direction == "credit":
        if "REFUND" in up:
            return RawEvent(kind=Kind.REFUND, merchant=parse_merchant(narr), **base)
        if "SALARY" in up:   # a candidate only: the USER confirms
            return RawEvent(kind=Kind.INCOME, salary_candidate=True, **base)
        return RawEvent(kind=Kind.INCOME, **base)
    if commitment_resolver is not None:
        cid = commitment_resolver(narr, ts)
        if cid:
            return RawEvent(kind=Kind.OBLIGATION_PAYMENT, commitment_id=cid, **base)
    merchant = parse_merchant(narr)
    return RawEvent(kind=Kind.CARD_PURCHASE if is_card else Kind.SPEND, merchant=merchant,
                    category=categorize_merchant(merchant), **base)


_SMS = re.compile(r"Rs\.?\s?([\d,]+(?:\.\d{1,2})?)\s+debited.*?(?:to\s+VPA\s+(\S+))?.*?"
                  r"(?:Ref(?:\s*No)?\.?\s*(\d{9,14}))?", re.I | re.S)


def from_sms_debit(text: str, account_id: str, received_ts: datetime) -> RawEvent | None:
    """Demo parser for e.g. 'Rs.450.00 debited from A/c XX1234 to VPA swiggy@icici. UPI Ref 482911003412'."""
    m = _SMS.search(text)
    if not m:
        return None
    vpa = re.search(r"VPA\s+(\S+?)[\.\s]", text + " ")
    ref = re.search(r"Ref(?:\s*No)?\.?\s*(\d{9,14})", text, re.I)
    merchant = vpa.group(1).split("@")[0].title() if vpa else None
    sid = hashlib.sha1(f"{text}|{received_ts.isoformat()}".encode()).hexdigest()[:16]
    return RawEvent(source="sms", source_id=sid, account_id=account_id, direction="debit",
                    amount_paise=rupees(m.group(1).replace(",", "")), ts=received_ts, kind=Kind.SPEND,
                    merchant=merchant, category=categorize_merchant(merchant),
                    ref=ref.group(1) if ref else None)
