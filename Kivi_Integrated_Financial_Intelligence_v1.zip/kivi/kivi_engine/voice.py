"""Kivi's voice. Numbers come from the engine; this only chooses tone and wording.

Tone routing (spec): distress -> no roast, supportive and action-first; uncertain data -> say so;
roast only with evidence and only when the user is not under financial stress.
Lines are original, not the founder's illustrative examples, and never claim WHAT was bought.
"""
from __future__ import annotations

from .insights import FoodPattern
from .money import fmt
from .safe2spend import Result


def tone(result: Result, pattern: FoodPattern | None) -> str:
    if result.state == "awaiting_payday":
        return "protective"
    if result.state == "insufficient":
        return "protective"
    if result.state == "shortfall" or result.overdue_obligations:
        return "distress"
    if result.confidence == "estimated":
        return "protective"
    if pattern is not None:
        return "playful"
    return "neutral"


def kivi_says(result: Result, pattern: FoodPattern | None = None, seed: int = 0) -> str:
    t = tone(result, pattern)
    if result.state == "awaiting_payday":
        return "Your expected salary hasn't arrived yet. What's your revised expected payday? I'll recalculate once you tell me."
    if result.state == "insufficient":
        return "I need two things before I give you a number: your latest balance and your last confirmed salary."

    if t == "distress":
        if result.overdue_obligations:
            name, due, amt = result.overdue_obligations[0]
            lead = f"{name} ({fmt(amt)}) was due on {due:%d %b}."
        else:
            lead = f"Right now your upcoming bills are {fmt(result.shortfall)} more than what's available."
        return (f"{lead} No judgement, let's sort this first. Nothing optional is safe to spend today. "
                f"Options: shrink or pause this cycle's goal contribution, or tell me if a bill can be split "
                f"or moved. Pick one and I'll recalculate.")

    left = result.display_left_today
    base = f"Safe to spend today: {fmt(max(left, 0))}"
    if left < 0:
        nxt = result.display_next_day_allowance
        after = (f"tomorrow's number adjusts to {fmt(nxt)}" if nxt is not None
                 else "this is the last day of the cycle, so the next number comes with your next salary")
        base = f"You're {fmt(-left)} over today's number. It's a guide, not a rule: {after}"
    tail = f" (cycle ends {result.cycle.last_day:%d %b})."
    if result.dipped_into_surplus > 0:
        base += f" (used {fmt(result.dipped_into_surplus)} of the room I'd parked)"
    if result.surplus_above_cap > 0 and left >= 0:
        tail += (f" You also have {fmt(result.surplus_above_cap)} of unspent room parked, not gone. "
                 f"Move it to a goal, or keep it for a treat?")

    if t == "protective":
        caveat = " ".join(result.notes[:2]) or "Some inputs are estimates."
        return f"{base}{tail} Heads up: this is an estimate. {caveat}"

    if t == "playful":
        late = (f", {pattern.late_night_orders} of them late at night" if pattern.late_night_orders else "")
        lines = [
            f"{pattern.orders} delivery orders in {pattern.window_days} days ({fmt(pattern.total_paise)}){late}. "
            f"Your kitchen is getting lonely. ",
            f"{fmt(pattern.total_paise)} on {pattern.orders} delivery orders this week{late}. "
            f"I'm not saying anything, I'm just keeping receipts. ",
            f"Delivery app loyalty is strong: {pattern.orders} orders, {fmt(pattern.total_paise)}{late}. "
            f"Enjoy it, just know the price. ",
        ]
        return f"{lines[seed % len(lines)]}{base}{tail}"

    return f"{base}{tail}"
