"""Synthetic user: produces AA-style transactions day by day so you can watch Kivi work.

Deterministic for a given seed. This validates the EXPERIENCE and the math; it cannot validate
accuracy or trust on real finances (that needs real users).
"""
from __future__ import annotations

import random
from dataclasses import dataclass, field
from datetime import date, datetime, time, timedelta

from .config import IST
from .cycle import clamp_day
from .ledger import Commitment


@dataclass(frozen=True)
class Recurring:
    key: str            # e.g. "rent"
    name: str
    keyword: str        # appears in the bank narration
    amount_paise: int
    day: int            # day of month


@dataclass
class Persona:
    name: str
    salary_paise: int
    payday_day: int
    recurring: list = field(default_factory=list)
    delivery_prob: float = 0.3
    late_night_prob: float = 0.2
    other_spend_prob: float = 0.5
    other_spend_range: tuple = (4000, 25000)       # paise
    delivery_range: tuple = (25000, 90000)         # paise
    card_prob: float = 0.05
    goal_key: str | None = None
    goal_amount_paise: int = 0


PERSONAS = {
    "foodie": Persona(
        "Food-delivery heavy, salary on the 28th", 40_000_00, 28,
        recurring=[Recurring("rent", "Rent", "RENT", 12_000_00, 1),
                   Recurring("emi", "Phone EMI", "PHONEEMI", 2_000_00, 5),
                   Recurring("netflix", "Netflix", "NETFLIX", 649_00, 8)],
        delivery_prob=0.55, late_night_prob=0.3, goal_key="bike", goal_amount_paise=3_000_00),
    "saver": Persona(
        "Disciplined saver, salary on the 1st", 55_000_00, 1,
        recurring=[Recurring("rent", "Rent", "RENT", 15_000_00, 3)],
        delivery_prob=0.08, other_spend_prob=0.35, goal_key="trip", goal_amount_paise=8_000_00),
    "stacked": Persona(
        "Stacked EMIs, tight on rent, salary on the 28th", 32_000_00, 28,
        recurring=[Recurring("rent", "Rent", "RENT", 13_000_00, 1),
                   Recurring("emi1", "Phone EMI", "PHONEEMI", 3_500_00, 5),
                   Recurring("emi2", "Laptop EMI", "LAPTOPEMI", 4_200_00, 6),
                   Recurring("bnpl", "BNPL", "BNPL", 2_800_00, 10)],
        delivery_prob=0.25),
}


def commitment_id(r: Recurring, due: date) -> str:
    return f"{r.key}-{due.isoformat()}"


def commitments_between(persona: Persona, first: date, last: date) -> list[Commitment]:
    out, d = [], date(first.year, first.month, 1)
    while d <= last:
        for r in persona.recurring:
            due = clamp_day(d.year, d.month, r.day)
            if first <= due <= last:
                out.append(Commitment(commitment_id(r, due), r.name, r.amount_paise, due))
        d = date(d.year + (d.month == 12), 1 if d.month == 12 else d.month + 1, 1)
    return out


def resolver_for(persona: Persona):
    """Match a bank narration to the commitment instance in that month."""
    def resolve(narration: str, ts: datetime):
        up = narration.upper()
        for r in persona.recurring:
            if r.keyword in up:
                d = ts.astimezone(IST).date()
                return commitment_id(r, clamp_day(d.year, d.month, r.day))
        return None
    return resolve


class Simulator:
    def __init__(self, persona: Persona, seed: int, opening_balance_paise: int):
        self.p, self.rng, self.balance, self.n = persona, random.Random(seed), opening_balance_paise, 0
        self.card_unpaid = 0

    def _ts(self, d: date, hour: int, minute: int | None = None) -> datetime:
        m = self.rng.randrange(60) if minute is None else minute
        return datetime.combine(d, time(hour, m), tzinfo=IST)

    def _txn(self, kind: str, amount: int, ts: datetime, narration: str, mode="UPI") -> dict:
        self.n += 1
        self.balance += amount if kind == "CREDIT" else -amount
        return {"txnId": f"SIM{self.n:06d}", "type": kind, "mode": mode,
                "amount": f"{amount / 100:.2f}", "currentBalance": f"{self.balance / 100:.2f}",
                "transactionTimestamp": ts.isoformat(), "valueDate": ts.date().isoformat(),
                "narration": narration, "reference": f"{self.rng.randrange(10**11, 10**12)}"}

    def spend_now(self, amount_paise: int, merchant: str, ts: datetime) -> dict:
        """The 'I just spent' button."""
        return self._txn("DEBIT", amount_paise, ts, f"UPI/{self.rng.randrange(10**11, 10**12)}/{merchant.upper()}/x@upi")

    def day_events(self, d: date) -> list[tuple[str, dict]]:
        """Returns [(account_id, aa_txn_dict)] for a date, in time order."""
        p, ev = self.p, []
        if d == clamp_day(d.year, d.month, p.payday_day):
            ev.append(("SB1", self._txn("CREDIT", p.salary_paise, self._ts(d, 9, 30),
                                        "NEFT-SALARY-ACMECORP", "NEFT")))
        for r in p.recurring:
            if d == clamp_day(d.year, d.month, r.day) and self.balance >= r.amount_paise:
                ev.append(("SB1", self._txn("DEBIT", r.amount_paise, self._ts(d, 11),
                                            f"{r.keyword}-PAYMENT-{r.key}", "NEFT")))
        if p.goal_key and d == clamp_day(d.year, d.month, p.payday_day) + timedelta(days=1):
            ev.append(("SB1", self._txn("DEBIT", p.goal_amount_paise, self._ts(d, 10),
                                        f"SELF-TRF-{p.goal_key.upper()}", "IMPS")))
        if self.rng.random() < p.delivery_prob:
            lo, hi = p.delivery_range
            late = self.rng.random() < p.late_night_prob
            hour = self.rng.choice([23, 0, 1]) if late else self.rng.choice([13, 14, 20, 21])
            amt = self.rng.randrange(lo, hi, 100)
            merchant = self.rng.choice(["SWIGGY", "ZOMATO"])
            if self.balance > amt:
                ev.append(("SB1", self._txn("DEBIT", amt, self._ts(d, hour),
                                            f"UPI/{self.rng.randrange(10**11, 10**12)}/{merchant}/{merchant.lower()}@icici")))
        if self.rng.random() < p.other_spend_prob:
            lo, hi = p.other_spend_range
            amt = self.rng.randrange(lo, hi, 100)
            payee = self.rng.choice(["RAMESH KUMAR", "CHAI POINT", "LOCAL KIRANA", "AUTO DRIVER", "PRIYA S"])
            if self.balance > amt:
                ev.append(("SB1", self._txn("DEBIT", amt, self._ts(d, self.rng.choice([9, 12, 16, 18])),
                                            f"UPI/{self.rng.randrange(10**11, 10**12)}/{payee}/x@upi")))
        if self.rng.random() < p.card_prob:
            amt = self.rng.randrange(50000, 300000, 100)
            self.card_unpaid += amt
            self.n += 1
            ev.append(("CC1", {"txnId": f"SIM{self.n:06d}", "type": "DEBIT", "mode": "CARD",
                               "amount": f"{amt / 100:.2f}", "currentBalance": "0",
                               "transactionTimestamp": self._ts(d, 15).isoformat(),
                               "valueDate": d.isoformat(), "narration": "UPI/000/AMAZON/card",
                               "reference": f"{self.rng.randrange(10**11, 10**12)}"}))
        if d.day == 15 and self.card_unpaid and self.balance >= self.card_unpaid:
            amt, self.card_unpaid = self.card_unpaid, 0
            ts = self._ts(d, 10)
            ref = f"{self.rng.randrange(10**11, 10**12)}"
            ev.append(("SB1", {**self._txn("DEBIT", amt, ts, "CARDPAY/CC1", "NEFT"), "reference": ref}))
            self.n += 1
            ev.append(("CC1", {"txnId": f"SIM{self.n:06d}", "type": "CREDIT", "mode": "NEFT",
                               "amount": f"{amt / 100:.2f}", "currentBalance": "0",
                               "transactionTimestamp": ts.isoformat(), "valueDate": d.isoformat(),
                               "narration": "CARDPAY/SB1", "reference": ref}))
        ev.sort(key=lambda x: x[1]["transactionTimestamp"])
        return ev
