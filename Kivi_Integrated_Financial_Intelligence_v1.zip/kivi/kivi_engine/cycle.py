"""Salary cycle: from actual payday to the day BEFORE the next payday. Never the calendar month.

Intervals are [start, end_exclusive). Salary 28 Oct, next 28 Nov -> 28 Oct..27 Nov, 31 days.
"""
from __future__ import annotations

import calendar
from dataclasses import dataclass
from datetime import date, timedelta


@dataclass(frozen=True)
class Cycle:
    start: date
    end_exclusive: date
    start_provenance: str  # "observed"
    end_provenance: str    # "confirmed_forecast" (user-given) | "predicted"
    overdue: bool          # as_of is on/after end_exclusive and no new salary observed

    @property
    def last_day(self) -> date:
        return self.end_exclusive - timedelta(days=1)

    @property
    def total_days(self) -> int:
        return (self.end_exclusive - self.start).days

    def days_remaining(self, as_of: date) -> int:
        """Days left INCLUDING today. Minimum 1 so late salary never divides by zero."""
        return max(1, (self.end_exclusive - as_of).days)


def clamp_day(year: int, month: int, day: int) -> date:
    return date(year, month, min(day, calendar.monthrange(year, month)[1]))


def predict_next_payday(start: date, usual_day: int | None = None) -> date:
    """Next month's payday, clamped to month length (31 Jan -> 28/29 Feb). A prediction only."""
    y, m = (start.year + 1, 1) if start.month == 12 else (start.year, start.month + 1)
    return clamp_day(y, m, usual_day or start.day)


def resolve_cycle(confirmed_salary_dates: list[date], as_of: date,
                  next_expected: date | None = None,
                  usual_day: int | None = None) -> Cycle | None:
    """Active cycle at `as_of`, or None if no confirmed salary has been observed yet."""
    starts = sorted(d for d in confirmed_salary_dates if d <= as_of)
    if not starts:
        return None
    start = starts[-1]
    if next_expected is not None and next_expected > start:
        end, prov = next_expected, "confirmed_forecast"
    else:
        end, prov = predict_next_payday(start, usual_day), "predicted"
    return Cycle(start, end, "observed", prov, overdue=as_of >= end)
