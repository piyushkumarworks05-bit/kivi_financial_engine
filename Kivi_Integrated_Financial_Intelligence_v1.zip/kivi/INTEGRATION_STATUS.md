# Kivi Financial Intelligence — Integrated source handoff

## Verified in this archive

- Python financial core: salary-cycle and revised payday policies, deterministic Safe 2 Spend, unpaid commitments, goal allocations, balance snapshots, credit-card outstanding handling, refunds, and conservative SMS/AA reference-based reconciliation.
- SMS parsing: rejection of OTP/promotions/failed payments, debit/credit extraction, uncertain messages routed for review, UPI reference/account-tail extraction, manual correction history.
- Durable local SQLite store, scoped by user key **but without authentication**. Do not expose the HTTP API publicly.
- `/onboarding`: user-reported salary, payday and balance. This is an estimate, not a verified bank balance.
- `/dashboard`: Safe 2 Spend, account summary, merchant-group analysis, spending targets, obligations, suspected recurring charges, roast evidence, and data-quality warnings.
- `/habit/projection`: private hypothetical spending-reduction calculations; never counted as actual savings.
- `/goal/forecast`: deterministic months-to-goal estimate; not a guarantee.
- `/demo/load?user=demo:...`: isolated synthetic financial profile; it is **not** a real AA response and cannot be silently combined with real accounts.
- User-supplied Umber and Expense Tracker codebases were reviewed as SMS design references. Their native Android code is **not** bundled or claimed to be integrated into Python.
- Kivi's separate personality content archive is available, but a production conversational AI runtime is not connected to this API.

## Run locally

Python 3.11+, standard library only. From `kivi/`:

```
python -m unittest discover -s tests -q
python -m kivi_engine.api
```

Onboarding example (in a second terminal):

```
curl -X POST 'http://127.0.0.1:8765/onboarding?user=local' -H 'Content-Type: application/json' -d '{"monthly_salary_paise":2500000,"payday_day":5,"available_balance_paise":1200000}'
curl 'http://127.0.0.1:8765/dashboard?user=local'
```

If the expected payday is overdue, Safe 2 Spend correctly waits for a revised payday instead of guessing. To set one, POST `/setting` with `{"key":"next_payday","value":"YYYY-MM-DD"}`.

Demo example:

```
curl -X POST 'http://127.0.0.1:8765/demo/load?user=demo:recruiter' -H 'Content-Type: application/json' -d '{}'
curl 'http://127.0.0.1:8765/dashboard?user=demo:recruiter'
```

## Not verified or implemented: do not represent as complete

- Android SMS inbox access, permission handling, background receiver, signed APK, or Play Store compliance.
- Live Setu/Finvu AA authorization, consent, callback verification, encryption of provider tokens, institution coverage, and FIU compliance. **No Setu client secret is present in this deliverable.** Never bundle provider secrets in an APK.
- Production authentication, tenant isolation enforcement, HTTPS, rate limiting, encrypted local storage, secure key management, operational monitoring, and security audit.
- Reliable parsing of all Indian bank SMS variants or real-bank integration certification.
- Credit-card billing-cycle precision, BNPL provider-specific rules, comprehensive investment valuation, verified net worth, cash-spend inference, and all disputed transactions.
- Full conversational AI, user intent extraction for targets, notification scheduling, personalized character avatar, actual graphic Roast Receipt export, or polished native mobile UX.
- The demo AA payload is synthetic and is not evidence of AA connectivity.

## Financial correctness notes

- User-reported balances are not verified; stale/missing account evidence must remain visible.
- Do not count SMS balance figures as bank-verified snapshots.
- SMS with no reliable reference should not automatically merge with a bank event merely because amount and time match.
- Spending targets are behavior goals, not obligations or protected funds.
- Sensitive categories must not be used in roasts.
- The currently implemented card logic conservatively reserves full card outstanding; statement-specific due amounts still require enhancement.
- Never present this development API as internet-safe or the current output as a certified production financial recommendation.
