# Kivi financial policies — founder approved, 23 Oct 2026

1. Late salary: never assume a seven-day extension. Return `awaiting_payday`, withhold a current allowance and ask for a future revised payday. Revised date is a forecast, not confirmed salary. Recalculate after response.
2. End-of-cycle: show the full actual calculated allowance. No historical-spend cap or hidden surplus.
3. Emergency reserve: user-optional, default ₹0; calculate in paise, reserve exactly once. Product UI must avoid separately excluding already protected money.

## Proposed engineering safety defaults — require review before launch
- Same-amount/same-time cross-source records are NOT automatically deduplicated without matching strong references. This avoids false merges but may temporarily overcount until reviewed.
- Other open areas: statement-due versus unbilled credit cards; stale/missing accounts and hard withholding thresholds; income source classification; refund settlement; balance snapshot reconciliation; user-approved goals and target semantics; transaction timestamp evidence; production AA/SMS parsers and security.
- No production database, API, Android app or live AA integration is included in this engine package.

## Verification
Run `python -m unittest discover -s tests -t . -v` from the `kivi` directory. Existing tests for superseded late-salary and surplus-cap policies were removed and replaced with new approved-policy regression tests. Test passing is not a production certification.
