# Kivi SMS Intelligence v3 — integrated engine

## What is implemented

- Evidence-first extraction of completed debit/credit, salary candidates, refunds, card purchases and bill payments.
- Reject OTPs, promotions, failed transactions, scheduled payments, and informational statements.
- Extract transaction amount separately from available balance; keep balance as **untrusted evidence** (not an account snapshot).
- Parse transaction reference, masked account tail, optional merchant/VPA, and explicit SMS date. Otherwise SMS receipt timestamp is a proxy, not asserted transaction time.
- Review instead of guessing when direction, account, amount, or sender is ambiguous.
- Source-ID replay protection and SMS/AA reconciliation through existing Kivi ledger using matching transaction reference; no time/amount-only merge.
- Existing SQLite Store persists accepted economic evidence and allows corrections.
- `/sms` and `/sms/batch` local endpoints return per-message decision and confidence.

## Data flow

Android SMS permission/receiver (future adapter) -> explicit account mapping -> `/sms/batch` -> SMS assessment -> accepted/review/ignored -> persistent Store -> AA matching -> Safe 2 Spend.

### API example

Run `python -m kivi_engine.api` inside the `kivi` directory. The development server binds to 127.0.0.1 and is NOT internet-safe.

```
POST /sms/batch
Content-Type: application/json
{
  "messages": [{
    "text": "A/c XX1234 debited by Rs 500.00. UPI Ref 512345678901. Avl Bal Rs 4500.00",
    "account_id": "bank1",
    "expected_account_tail": "1234",
    "sender": "VK-HDFCBK",
    "source_id": "device-message-1",
    "received_ts": "2026-10-23T10:00:00+05:30"
  }]
}
```

Create `bank1` first with `/account`. For production, do not trust client-provided `user` query parameters; implement authenticated user identity and tenant isolation.

## Sources examined

- User-supplied `Expense_tracker-main.zip`: `lib/parser/message_parser_pipeline.dart`, `lib/parser/financial_regex_patterns.dart`, SMS sync/receiver modules.
- User-supplied `umber-main(1).zip`: `app/src/main/java/com/deepak/umber/parse/SmsParser.kt`, SMS backfill/receiver modules.

This implementation is original Python code informed by their rejection and extraction approaches; their source code is not silently copied or relicensed. Both repos remain reference material, not embedded runtime dependencies.

## Honest limitations

- Not all Indian bank templates are supported; bank-specific corpus tests and field validation are still required.
- No Android SMS permission receiver wired into this Python backend. Native SMS access also depends on Android permissions and Google Play policy eligibility.
- SMS sender headers can be spoofed; header format alone does not prove authenticity.
- Ambiguous messages are returned for review; they are not silently posted to the ledger.
- `/sms/batch` accepts synthetic or caller-supplied SMS; it does not access a phone's inbox.
- Real AA provider access and live bank reconciliation are not provided by this ZIP.
- Real-time bank balance should come from authenticated bank/AA evidence; an SMS-reported balance is not treated as authoritative.

## Verification

`python -m unittest discover -s tests -q`
