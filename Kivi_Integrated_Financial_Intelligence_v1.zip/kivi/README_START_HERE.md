# Kivi Financial Engine + Local App (development build)

## Run it

Requires Python 3.11+. No pip dependencies required.

```bash
cd kivi
python -m unittest discover -s tests -t . -q
python -m kivi_engine.api
```

Open **http://127.0.0.1:8765** on the same computer. The browser UI supports adding a local account and opening balance, confirmed salary, next payday, emergency reserve, and conversational-style merchant spending targets. It shows calculated Safe 2 Spend, spending summary, and suspected recurring charges.

## What works

- Existing deterministic salary-cycle Safe 2 Spend engine, approved no-cap, late-payday and optional reserve policies.
- Durable local SQLite accounts, snapshots, raw transaction evidence, audit corrections, commitments, goals, settings and targets, isolated by user ID in the database.
- Local JSON API, SMS normalization, AA-style transaction import, evidence-based dedupe, manual review candidates, spending summary and suspected recurring charges.
- Browser-based responsive local app.

## What is NOT production-ready

**This is not a complete Android app or deployable consumer-finance product.** The local HTTP API has no authentication, no TLS and no tenant authorization; user IDs are supplied by the caller. **Never expose port 8765 to the internet.** It intentionally binds to localhost. The Account Aggregator adapter handles approximate payload shapes, not live Finvu/Setu authorization/consent. SMS support is conservative and partial; it does not read Android SMS automatically. Bank balance data must be supplied or imported. The credit-card model still reserves full outstanding instead of due-only statement amounts. No live AI, Android package, secure cloud deployment, notification scheduler or visual Roast Receipt generator is included. The app is usable for local testing of the financial engine, not real financial decisions.

All values are stored in integer paise. Transaction references are required for automatic cross-source deduplication; suspected matches are review candidates only. Spending targets do not reserve money.
