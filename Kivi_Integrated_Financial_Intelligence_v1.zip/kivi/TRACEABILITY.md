# Kivi traceability matrix (v0.1 prototype engine)

Founder rule → where it lives → test. "Spec §" refers to *Kivi Full Product Specification* (22 Oct 2026).
Status: **implemented + tested** unless marked otherwise. Nothing here is validated on real bank data.

| # | Rule (spec §) | Code | Tests |
|---|---|---|---|
| 1 | Cycle = payday → day before next payday; 28 Oct–27 Nov = 31 days; no reset on 1 Nov (§5.1) | `cycle.py` | `TestCycle.test_oct28_to_nov28...`, `...payday_28`, `test_every_cycle_starts_on_a_payday...` |
| 2 | Salary on 5th runs to the 4th (§5.1) | `cycle.py` | `test_salary_on_5th_runs_to_4th` |
| 3 | Jan 31 + confirmed Feb 28 boundary; no invented Feb 31; leap years (§18) | `predict_next_payday` | `test_jan31_with_confirmed_feb28...`, `test_payday_31_prediction_clamps...` |
| 4 | Early salary starts a new cycle on the observed date (§5.6) | `resolve_cycle` | `test_early_salary...` |
| 5 | A credit is not automatically salary; unconfirmed credit does not reset the cycle or inflate the number (§4.2, §17) | `ledger.pending_salary_candidates`, `safe2spend.compute` | `test_unconfirmed_salary_credit...` |
| 6 | Mid-cycle signup uses current balance + unpaid dues, not the original salary (§5.4) | `safe2spend.compute` | `test_mid_cycle_signup...` |
| 7 | ₹200 plan / ₹500 spend / 5 days left → ₹60 less per day; underspend carries (§5.3) | `safe2spend` (recomputed from state, no additive counter) | `test_rolling_overspend...`, `test_underspend_carries_forward` |
| 8 | Balance snapshot already reflects past debits: never subtract twice (§4.2) | `Ledger.liquid_balance` | `test_already_paid_debit_in_snapshot...`, `test_debit_after_snapshot_is_applied_exactly_once` |
| 9 | Paid rent not reserved; unpaid rent is; EMI reserved until paid (§5.7, §11) | `safe2spend.compute` | `test_paid_rent_not_reserved...` |
| 10 | Only obligations due within the cycle are reserved | `safe2spend.compute` | `test_obligation_due_after_cycle_not_reserved` |
| 11 | Goal +₹1,000 lowers capacity by ₹1,000; already-transferred goal not deducted twice (§9, §18) | `compute`, `goal_funded_since` | `test_goal_increase...`, `test_goal_contribution_already_transferred...` |
| 12 | Shortfall shown explicitly, never a green number (§5.7) | `Result.state` | `test_shortfall_is_explicit...` |
| 13 | Stale balance / predicted payday / partial coverage → labeled estimated (§5.6, §18) | `Result.confidence` | `test_stale...`, `test_predicted_payday...`, `test_incomplete_account...` |
| 14 | Missing balance or salary → no number (§0) | `state="insufficient"` | `test_missing_balance_gives_no_number` |
| 15 | Idempotent ingestion; duplicate SMS + AA = one event, both raw records kept (§4.2, §18) | `Ledger.ingest` | `test_replay...`, `test_sms_and_aa...` |
| 16 | Two real same-amount purchases from one source stay two; different refs never merge | `_same_event` | `test_two_identical...`, `test_different_references...` |
| 17 | Own-account transfer is neither spend nor income (§18) | `Kind.TRANSFER_OWN` | `test_own_account_transfer...` |
| 18 | Card purchase then card payment counts consumption once (§11, §18) | `card_outstanding`, `_pair_legs` | `test_card_purchase_then_card_payment...`, `..._only_liquid_leg...` |
| 19 | Refund must link to the original; unlinked refunds are flagged (§18) | `link_refund`, `unlinked_refunds` | `test_refund_linked...` |
| 20 | Unknown UPI debit stays unknown; never infer the purchased item (§0, §2.3) | `aa_adapter`, `insights` | `test_unknown_upi_debit_stays_unknown`, `test_unknown_merchants_do_not_trigger...` |
| 21 | User corrections audited and persist over later sources (§4.2) | `reclassify`, `audit` | `test_user_correction_persists...` |
| 22 | Amounts are integer paise; timestamps tz-aware (§4.2) | `money.py`, `Ledger.ingest` | `test_naive_timestamps_rejected`, `test_money_helpers` |
| 23 | Roast only with evidence; never invents items; none during distress (§2, §13, §17) | `insights.py`, `voice.py` | `TestKiviVoice.*` |
| 24 | Roast is not constant (§13) | `World.view` cooldown, `Config.roast_cooldown_days` | `test_roast_cooldown...` |
| 25 | Deterministic recomputation; ledger tracks simulated bank balance | all | `TestSimulatorEndToEnd.*` |

## Not built yet (honest list)
Habits (§10), Ghost Purchases (§12), Roast Receipt image and sharing/redaction (§13.1), Adaptive Budget (§8), Goal feasibility from 3–5 months of history (§9), Financial Tracker view (§6), debt calendar beyond reserving dues (§11), persistence (PostgreSQL), auth/tenant isolation, encryption, real Setu/Finvu sandbox calls, UI, deployment.

## Open decisions: current engineering defaults (`config.py`), all need your sign-off
Rounding: floor to whole rupee · stale balance after 48h · emergency reserve ₹0 · dedupe window 15 min · no time-of-day proration · card outstanding is reserved immediately · roast cooldown 3 days · negative allowance shown as shortfall, never a negative "safe" number.
Still undecided and **not** implemented: payday prediction when no history, multiple income sources, card holds, overdraft, retention periods, notification defaults.

## v0.2 changes (two fixes from the founder-logic review)
| # | Rule | Code | Tests |
|---|---|---|---|
| 26 | Late salary never turns the whole balance into today's number: spread over `overdue_assumed_days` (default 7), labeled estimated | `safe2spend.compute`, `Config.overdue_assumed_days` | `TestLateSalary.*` |
| 27 | End-of-cycle number is capped for display (default 2x normal daily room, only with 7+ spending days of history); the excess is reported as `surplus_above_cap` and offered to a goal or a treat. Raw math unchanged, shortfall never softened | `safe2spend._surplus_cap`, `Result.display_*`, `voice.py` | `TestSurplusCap.*` |

Both defaults (7 days, 2x) are engineering assumptions and need founder sign-off. UI code should show `display_allowance_today` and `display_next_day_allowance`, and use `surplus_above_cap` for the "move it to a goal / keep for a treat" prompt.

## v0.3 changes (found while reviewing v0.2; each has a test and was mutation-checked)
| # | Rule | Code | Tests |
|---|---|---|---|
| 28 | When salary is late, bills due inside the assumed spread (not only before the old predicted end) are still reserved. Without this the number was falsely green | `safe2spend.compute` (`horizon_end`) | `TestV03Fixes.test_late_salary_still_reserves...`, `..._ignores_bills_beyond...` |
| 29 | Spending past the capped display number draws from the parked surplus first; "over" only when the REAL allowance is exceeded. Parked surplus shrinks accordingly; nothing vanishes | `Result.display_left_today`, `dipped_into_surplus` | `test_spending_past_the_cap...`, `test_nothing_vanishes...` |
| 30 | No "tomorrow's number" claim on the last day of a cycle (old v0.1 bug: printed ₹0) | `voice.py` | `test_no_tomorrow_claim...` |

Still needs founder sign-off: the 7-day late-salary spread, the 2x display cap, and the 7-spending-day minimum before capping. Note the cap deliberately shows less than the raw "safe" amount; the spec calls the number a permission signal, so decide whether the app should ever show less than what is truly safe.
