# Kivi — Engine-Locked Screen Contracts v1

**Purpose:** Prevent UI screens from contradicting Kivi's actual financial intelligence. Based on the uploaded Kivi Product Spec, approved pop-culture moodboard, and inspection of `Kivi_Integrated_Financial_Intelligence_v1.zip` (`api.py`, `service.py`, `intelligence.py`, `INTEGRATION_STATUS.md`).

## Non-negotiable rules

1. All rupee figures come from the engine in **integer paise**; UI only formats them. Never recompute Safe 2 Spend in the app.
2. Personal onboarding: salary, payday, **user-reported** available bank balance. Salary is not added to current balance. SMS can provide transaction evidence but does not automatically prove the latest bank balance.
3. When payday passes without confirmed salary, ask for revised payday; don't silently extend by seven days. Show no verified allowance until the engine has adequate inputs.
4. No arbitrary daily allowance cap. Optional reserve only if user chooses it. No double counting of paid commitments, transfers, or AA/SMS duplicate evidence.
5. **Personal and demo data are isolated.** Synthetic AA data must have a visible demo label and must not affect personal Safe 2 Spend.
6. Conversational targets are not bills or reserves. Projected habit savings are not realized savings. Ghost purchases are suspected, not known forgotten purchases.
7. No roast about medical, debt distress, addictions/habits, or shame. No invented merchants, products, purchases, or balances.
8. **Never use either banned pet name from the user's instruction anywhere in generated app copy.** Official tagline: **Let's unf*ck your money habits.**
9. Design authority: uploaded pop-culture moodboard; ink `#0F1210`, paper `#F6EFE2`, lime `#C6FF3D`, pink `#FF3E7F`, gold `#FFB627`, violet `#8A6BFF`, orange `#FF6B2C`, sky `#3DB8FF`. Filmi editorial, receipt texture, meme-native wit. No gaming dashboards, XP, glowing tiles, or streak rewards.
10. Do not represent missing backend features as functional. Build them, test them, then unlock corresponding UI actions.

## Screen-by-screen contracts

### KIVI-S01 — Welcome

**Engine/API:** `none`  
**Current readiness:** Entry  
**Displays:** Tagline, Kivi identity, continue  
**Interactions:** Start onboarding  
**Safety/invariant:** No financial number before setup  
**Required states:** Loading, ready, partial/estimated, empty, error.

### KIVI-S02 — Salary onboarding

**Engine/API:** `POST /onboarding`  
**Current readiness:** Input  
**Displays:** Monthly salary in INR, salary day 1–31, current user-reported available balance  
**Interactions:** Submit onboarding; retain user-reported provenance  
**Safety/invariant:** Never add salary to current balance; missing data means no calculated number  
**Required states:** Loading, ready, partial/estimated, empty, error.

### KIVI-S03 — SMS consent

**Engine/API:** `POST /sms/batch (backend only)`  
**Current readiness:** Native Android SMS bridge NOT IMPLEMENTED  
**Displays:** Explain permission, import period, local processing and review  
**Interactions:** Grant/deny; denial offers manual import  
**Safety/invariant:** Never claim Android SMS is implemented in backend  
**Required states:** Loading, ready, partial/estimated, empty, error.

### KIVI-S04 — SMS import review

**Engine/API:** `POST /sms/batch results`  
**Current readiness:** accepted/review/rejected  
**Displays:** Counts, merchant, amount, direction, reason, confidence  
**Interactions:** Review ambiguous items; correct via POST /correct  
**Safety/invariant:** Do not count review items as confirmed spending  
**Required states:** Loading, ready, partial/estimated, empty, error.

### KIVI-S05 — Financial setup review

**Engine/API:** `GET /dashboard data_quality; upcoming_obligations`  
**Current readiness:** Partial  
**Displays:** Balance provenance, detected unpaid obligations, missing accounts  
**Interactions:** Confirm obligations; correct classifications  
**Safety/invariant:** User-reported balance must be labeled as such  
**Required states:** Loading, ready, partial/estimated, empty, error.

### KIVI-S06 — Home Safe 2 Spend

**Engine/API:** `GET /dashboard.safe2spend`  
**Current readiness:** Calculated/estimated/awaiting date/unavailable  
**Displays:** allowance_today_paise, spent_today_paise, left_today_paise, days_remaining, notes, breakdown, next_payday  
**Interactions:** Explain calculation, revise payday via POST /setting  
**Safety/invariant:** No independent UI arithmetic; no cap; no fake amount if unavailable  
**Required states:** Loading, ready, partial/estimated, empty, error.

### KIVI-S07 — Safe 2 Spend explanation

**Engine/API:** `GET /dashboard.safe2spend.breakdown`  
**Current readiness:** same as Home  
**Displays:** Balance, due commitments, approved unfunded savings, optional reserve, data warnings  
**Interactions:** Review underlying records  
**Safety/invariant:** Do not deduct paid expenses twice  
**Required states:** Loading, ready, partial/estimated, empty, error.

### KIVI-S08 — Financial Tracker

**Engine/API:** `GET /dashboard.financial_tracker`  
**Current readiness:** Known/partial  
**Displays:** accounts, net_worth_known_paise, missing_accounts  
**Interactions:** Inspect account and source freshness  
**Safety/invariant:** Known net worth is not verified total net worth  
**Required states:** Loading, ready, partial/estimated, empty, error.

### KIVI-S09 — Transaction feed

**Engine/API:** `Ledger storage; API endpoint MISSING`  
**Current readiness:** Blocked until API added  
**Displays:** Transaction date, merchant, type, confidence, source, duplicate status  
**Interactions:** Correct via POST /correct; filter/search needs endpoint  
**Safety/invariant:** Do not fake transaction history from spending summaries  
**Required states:** Loading, ready, partial/estimated, empty, error.

### KIVI-S10 — Spending analysis

**Engine/API:** `GET /dashboard.spending_intelligence`  
**Current readiness:** Partial  
**Displays:** spent_paise, merchant_groups_paise, categories_paise, daily_paise, percent_of_income, income_basis  
**Interactions:** Explore category and merchant  
**Safety/invariant:** Income denominator must disclose user-reported vs confirmed  
**Required states:** Loading, ready, partial/estimated, empty, error.

### KIVI-S11 — Spending targets

**Engine/API:** `GET /dashboard.conversational_targets; POST /target`  
**Current readiness:** Partially implemented  
**Displays:** spent_paise, ceiling_paise, exceeded  
**Interactions:** Set/edit target; NLP extraction NOT IMPLEMENTED  
**Safety/invariant:** reserved_money_paise must remain zero  
**Required states:** Loading, ready, partial/estimated, empty, error.

### KIVI-S12 — Goals and savings

**Engine/API:** `GET /dashboard.goals; POST /goal; POST /goal/forecast`  
**Current readiness:** Partial  
**Displays:** approved allocations, estimated months to goal  
**Interactions:** Create/adjust goals; enforce max 2 in product layer  
**Safety/invariant:** Projected savings not realized money; max 2 not enforced in current backend  
**Required states:** Loading, ready, partial/estimated, empty, error.

### KIVI-S13 — EMI and BNPL

**Engine/API:** `GET /dashboard.upcoming_obligations`  
**Current readiness:** Partial  
**Displays:** items, due, unpaid_paise, total_unpaid_paise  
**Interactions:** Confirm/add obligations via POST /commitment  
**Safety/invariant:** Full card billing and BNPL extraction NOT IMPLEMENTED  
**Required states:** Loading, ready, partial/estimated, empty, error.

### KIVI-S14 — Habits and spending

**Engine/API:** `POST /habit/projection`  
**Current readiness:** Projection only  
**Displays:** potential_monthly_savings_paise, realized_savings_paise=0  
**Interactions:** Opt-in private reduction estimate  
**Safety/invariant:** Never show habit details on lock screen or in roasts  
**Required states:** Loading, ready, partial/estimated, empty, error.

### KIVI-S15 — Ghost purchases

**Engine/API:** `GET /dashboard.ghost_purchases`  
**Current readiness:** Suspected only  
**Displays:** merchant, reason, amount_changed, question  
**Interactions:** Mark still using/not recognized (feedback endpoint MISSING)  
**Safety/invariant:** Never state user forgot; suspicious charge is security concern  
**Required states:** Loading, ready, partial/estimated, empty, error.

### KIVI-S16 — Roast Receipt

**Engine/API:** `GET /dashboard.roast_receipt`  
**Current readiness:** Evidence only  
**Displays:** eligible, archetype, merchant, line, hide_amounts_by_default  
**Interactions:** Reveal optional amounts; share graphic export NOT IMPLEMENTED  
**Safety/invariant:** Exclude sensitive categories and never fabricate facts  
**Required states:** Loading, ready, partial/estimated, empty, error.

### KIVI-S17 — Kivi conversation

**Engine/API:** `Financial dashboard context; personality runtime NOT CONNECTED`  
**Current readiness:** Integration missing  
**Displays:** Grounded finance answers with confidence, nonjudgmental humor  
**Interactions:** Ask follow-ups, create target via explicit action  
**Safety/invariant:** No invented financial facts; no banned terms  
**Required states:** Loading, ready, partial/estimated, empty, error.

### KIVI-S18 — Demo AA profile

**Engine/API:** `POST /demo/load?user=demo:...; GET /dashboard?user=demo:...`  
**Current readiness:** Synthetic  
**Displays:** Separate demo banner and sample financial tracker  
**Interactions:** Enter/exit demo  
**Safety/invariant:** Never combine demo transactions with personal Safe 2 Spend  
**Required states:** Loading, ready, partial/estimated, empty, error.

### KIVI-S19 — Notifications and settings

**Engine/API:** `POST /setting limited keys`  
**Current readiness:** Partial  
**Displays:** Data freshness, notification preferences, privacy and permissions  
**Interactions:** Change settings, clear data; notification scheduler NOT IMPLEMENTED  
**Safety/invariant:** No fake permission or notification controls  
**Required states:** Loading, ready, partial/estimated, empty, error.

## Critical user journeys (end-to-end acceptance)

**Personal onboarding:** Enter ₹25,000 salary, salary day 5, ₹12,000 reported balance → save via `/onboarding` → dashboard shows user-reported provenance, computes only when cycle/date and obligations are sufficient. Never treat ₹25,000 as new liquid funds.

**SMS ingestion:** Android consent → native reader (to be implemented) → batch `/sms/batch` → accepted/review/rejected → ledger update → refresh `/dashboard` → financial number and spending analysis agree. Duplicate AA/SMS evidence must not double count.

**Payday delayed:** Expected payday passes without confirmed credit → engine requests revised date → UI asks and POSTs `/setting` `next_payday` → refresh; no fabricated verified amount during missing-date state.

**Demo AA:** Load only `demo:` user → visible synthetic-data banner → demo tracker and insights → switching to personal restores personal state unchanged.

**Corrections:** User reclassifies transaction via `/correct` → recompute dashboard → Safe 2 Spend, spending, targets and roast evidence derive from the same corrected ledger. Do not claim this flow is complete until UI transaction list and API read endpoint are added.

**Financial distress:** Kivi stops jokes and prioritizes upcoming obligations and available money. No shame-based notifications.

## Backend gaps that must be implemented before full-screen parity

- Native Android SMS permission, historical inbox import, background delivery, APK signing and installation.
- Read/list/search transaction API and review queue with durable disposition; account detail and freshness endpoints.
- Merchant mapping and robust Indian-bank SMS format coverage; credit-card statement due vs unbilled liability precision.
- Live AA/Setu secure server integration (demo profile exists, not live AA).
- Goals: two-goal enforcement, funding reconciliation, actual progress; full BNPL schedule and payment confirmation.
- Conversation runtime, target intent parsing, Kivi persona integration; receipt graphic export and share sheet.
- Notifications scheduler, permissions, user preference controls; production authentication/encryption and privacy controls.

## Integration gate

For each screen, require: (a) engine source mapping, (b) exact JSON contract, (c) ready/partial/error snapshots, (d) user action API tests, (e) screenshot QA against moodboard, (f) one end-to-end Android test. A screen must never display fabricated figures while waiting for its backend.
