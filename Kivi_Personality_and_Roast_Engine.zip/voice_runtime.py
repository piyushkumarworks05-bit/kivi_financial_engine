import json, re
from pathlib import Path
DATA = json.loads((Path(__file__).parent / "kivi_personality_engine.json").read_text(encoding="utf-8"))
SENSITIVE = {"medical", "addiction", "debt_distress", "fraud", "security", "shame"}
REQUIRED = re.compile(r"\{([a-z_]+)\}")

def render(event, facts=None, *, signals=(), surface="in_app", seed=0):
    facts = facts or {}
    signals = set(signals)
    if signals & SENSITIVE or "stress" in signals:
        event = "financial_stress" if "fraud" not in signals and "security" not in signals else None
    if event is None:
        return {"mode": "security", "text": "This may need a security review. Please verify the transaction with your bank.", "roast": False}
    if event not in DATA["triggers"]:
        return {"mode": "neutral", "text": "I need more information to explain this accurately.", "roast": False}
    if surface not in DATA["triggers"][event]["allowed_surfaces"]:
        return {"mode": "suppressed", "text": "", "roast": False}
    scripts = [x for x in DATA["scripts"] if x["event"] == event and all(k in facts for k in REQUIRED.findall(x["text"]))]
    if not scripts:
        return {"mode": "uncertain", "text": "I need to confirm the details before I comment on this.", "roast": False}
    line = scripts[seed % len(scripts)]["text"].format(**facts)
    if any(re.search(r"\b"+w+r"\b",line,re.I) for w in DATA["policy"]["forbidden_terms"]):
        raise ValueError("Forbidden brand term")
    return {"mode": "stress" if event=="financial_stress" else "normal", "text": line, "roast": event in {"food_delivery","late_night","roast_receipt"}}
