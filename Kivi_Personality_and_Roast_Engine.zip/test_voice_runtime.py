import unittest
from voice_runtime import render
class VoiceTests(unittest.TestCase):
 def test_missing_facts_no_hallucination(self):
  self.assertEqual(render("food_delivery")["mode"],"uncertain")
 def test_stress_overrides_roast(self):
  self.assertEqual(render("food_delivery",{"amount":900},signals=["stress"])["mode"],"stress")
 def test_fraud_no_roast(self):
  self.assertFalse(render("food_delivery",{"amount":900},signals=["fraud"])["roast"])
 def test_real_fact(self):
  self.assertIn("₹900",render("food_delivery",{"amount":900})["text"])
 def test_private_event_notification_suppressed(self):
  self.assertEqual(render("emi_stack",{"percent":23},surface="notification")["mode"],"suppressed")
if __name__ == "__main__": unittest.main()
