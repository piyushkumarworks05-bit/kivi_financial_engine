# Kivi — Personality, Dialogue & Roast Engine

## Identity
Kivi is an original, confident, observational Indian Gen Z financial companion. She roasts behavior, never a person. The engine is a content-and-policy contract, not a trained language model.

## Brand
Tagline: **Let’s unf*ck your money habits.**
Forbidden terms: **babe**, **bestie** (including notifications and receipts).

## Humor DNA
Observational comedy; tight setup/punchline; deadpan; cinematic framing; specific verified facts; callbacks; natural Hinglish. Inspired by comedy craft, not any particular performer’s protected material or distinctive imitation.

## Decision pipeline
1. Read event and verified evidence.
2. Determine security, stress, shame, uncertainty, and privacy state.
3. Suppress roasts in sensitive or uncertain situations.
4. Choose one suitable original script and fill placeholders only from verified fields.
5. Attach evidence IDs; never infer unsupported details.
6. Give one useful next action.
7. Apply user preferences, cooldown, and notification privacy.

## Tone examples

### Salary Arrived
- Salary credited. The season premiere has arrived. Let’s make sure the money survives the plot.
- Salary is in. Opening weekend looks strong. Now let’s check what’s already booked.
- Salary day. Main character entry, supporting cast: rent and EMIs.
- Payday landed. Aaj ka plot: protect the essentials, enjoy the rest.

### Safe To Spend
- ₹{safe} is your Safe 2 Spend today. That’s spending room, not homework.
- Today’s number: ₹{safe}. Permission, not a challenge.
- ₹{safe} today. No dramatic background music required.
- ₹{safe} is available today, based on what we know.

### Food Delivery
- ₹{amount} on delivery this cycle. The kitchen has officially become a guest appearance.
- Delivery has taken ₹{amount} this cycle. The stove deserves a cameo.
- ₹{count} delivery orders. The doorbell has more screen time than your cookware.
- Food delivery is {percent}% of your income. That’s a whole subplot.

### Late Night
- Another midnight order? Your cravings have a better release schedule than most films.
- A 1 a.m. order. The plot twist was apparently hunger.
- The midnight snack cinematic universe expands.
- Your late-night orders are building a franchise.

### Emi Stack
- EMIs take {percent}% of this cycle’s income. That’s a major supporting role—let’s keep the next payment covered.
- Your instalments have a packed calendar. Next due: {due_date}.
- There are {count} upcoming instalments. No roast here—let’s keep the dates clear.
- ₹{amount} in unpaid instalments before payday. I’ve accounted for them.

### Ghost Purchase
- ₹{amount} keeps showing up for {merchant}. Still using it, or is this a subscription with a secret second life?
- {merchant} made another appearance. Want to check whether it still earns its screen time?
- Possible recurring charge spotted: {merchant}. Shall we review it?
- This might be a forgotten subscription—not confirmed. Want a closer look?

### Goal Progress
- Your {goal} fund moved up by ₹{amount}. Quiet progress. Excellent plot development.
- {goal} is getting closer. No montage required—just consistency.
- You’re {percent}% of the way to {goal}. The sequel is looking promising.
- The {goal} timeline just improved. Nice work.

### Under Spend
- You spent less than the plan today. Tomorrow gets a little more breathing room.
- Money left over. Not a trophy—just more choices.
- That’s ₹{amount} still available. Carry it forward or keep it quiet.
- The wallet got a rare peaceful episode today.

### Over Spend
- Today ran above the earlier allowance. I’ve recalculated the days ahead—no scolding, just the new number.
- The spending plot changed. Here’s the updated Safe 2 Spend.
- That purchase shifted the daily average. We can work with the updated picture.
- New balance, new math. No red-alert soundtrack.

### Unknown Merchant
- I can see ₹{amount} went out, but I can’t identify the merchant reliably. Can you confirm it?
- This transaction needs a name. I won’t make one up.
- Unknown merchant, confirmed amount. Want to label it?
- The payment is real; the category is still a question mark.

### Financial Stress
- I hear you. Let’s look at what is due first and what can wait.
- That sounds stressful. We’ll sort the immediate payments one at a time.
- I’m here. Let’s get a clear picture before deciding anything.
- No jokes right now. Tell me which payment is worrying you most.

### Late Salary
- Salary hasn’t appeared yet. What date are you expecting it now? I won’t guess.
- Payday moved? Tell me the revised date so I can recalculate accurately.
- I can show your current balance, but I need a revised payday before giving a fresh daily number.
- Let’s update the expected salary date first.

### Data Stale
- Your balance hasn’t updated recently, so I’m not calling this number confirmed.
- The data needs a refresh before I can trust today’s allowance.
- A fresh balance would make this calculation reliable.
- I can show the last known picture, clearly marked as old.

### Refund
- ₹{amount} refund detected. I’ll count it as available once it’s reflected in your balance.
- Refund on the way. No victory lap until it actually lands.
- Refund confirmed in your balance. The math has been updated.
- That refund has landed. Your spending room has been recalculated.

### Roast Receipt
- NOW SHOWING: THE DELIVERY EXTENDED CUT. Genre: domestic comedy. Lead actor: your doorbell.
- MONTHLY BOX OFFICE: The Snack Cinematic Universe. Plot: frequent cameos by food delivery.
- THE SUBSCRIPTION SEQUEL. Same cast, recurring monthly appearance.
- RECEIPT REVIEW: Your coffee orders have a more reliable schedule than your calendar.

### Notification
- Today’s Safe 2 Spend is ready. The math has entered the chat.
- Plot update: your spending room has changed. Tap for the numbers.
- New spending insight. No lecture, just receipts.
- A recurring charge might deserve a second look.

## Guardrails and acceptance checks
- If medical, debt distress, addiction, fraud or shame: no roasts.
- If amount or merchant is uncertain: ask for confirmation, do not generate specific jokes.
- If receipt is shared: remove amounts by default, never include private merchant names in sensitive categories.
- Never present a guessed salary or unverified bank balance as confirmed.
- Kivi may be witty without jokes: facts remain legible and accurate.
- Daily engagement copy is distinct from financial alerts.

## Integration
The app passes structured financial facts, evidence IDs, tone state, privacy preferences and UI surface. The engine selects content and returns a typed response; the deterministic financial engine alone computes Safe 2 Spend.

## Not included
This package is the authored voice policy and script library, not a live LLM API, voice synthesis, Android APK, or automatic financial data integration.